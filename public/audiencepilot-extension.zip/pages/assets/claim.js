(() => {
  const overlay = document.createElement("div");
  overlay.id = "extension-claim-lock";
  overlay.style.cssText = [
    "position:fixed",
    "inset:0",
    "z-index:99999",
    "display:flex",
    "align-items:center",
    "justify-content:center",
    "padding:20px",
    "box-sizing:border-box",
    "background:rgba(248,250,252,.98)",
    "font:13px/1.45 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif",
    "color:#172033"
  ].join(";");

  const card = document.createElement("div");
  card.style.cssText = [
    "box-sizing:border-box",
    "width:min(360px,100%)",
    "padding:22px",
    "background:#ffffff",
    "border:1px solid #bfdbfe",
    "border-radius:14px",
    "box-shadow:0 12px 32px rgba(15,23,42,.16)"
  ].join(";");

  const title = document.createElement("h1");
  title.textContent = "Extension locked";
  title.style.cssText = "margin:0;font-size:20px;line-height:1.2;color:#172b4d";

  const description = document.createElement("p");
  description.textContent = "Generate an unlock code in the web app Settings page, then enter it here to connect this extension to your account.";
  description.style.cssText = "margin:9px 0 16px;color:#64748b";

  const input = document.createElement("input");
  input.type = "text";
  input.placeholder = "Enter unlock code";
  input.autocomplete = "off";
  input.style.cssText = "box-sizing:border-box;width:100%;padding:10px 11px;border:1px solid #cbd5e1;border-radius:7px;text-transform:uppercase;letter-spacing:.12em;font:600 15px ui-monospace,SFMono-Regular,Menlo,monospace";

  const button = document.createElement("button");
  button.type = "button";
  button.textContent = "Unlock extension";
  button.style.cssText = "margin-top:11px;width:100%;padding:10px 11px;border:0;border-radius:7px;background:#2563eb;color:white;font-weight:700;cursor:pointer";

  const status = document.createElement("p");
  status.style.cssText = "min-height:19px;margin:10px 0 0;color:#64748b";

  button.addEventListener("click", () => {
    const code = input.value.trim().toUpperCase();
    if (!code) {
      status.textContent = "Enter a code first.";
      status.style.color = "#b91c1c";
      return;
    }

    button.disabled = true;
    button.style.opacity = ".6";
    status.textContent = "Unlocking...";
    status.style.color = "#64748b";
    chrome.runtime.sendMessage({ action: "claimExtension", code }, (result) => {
      button.disabled = false;
      button.style.opacity = "1";
      if (chrome.runtime.lastError) {
        status.textContent = chrome.runtime.lastError.message;
        status.style.color = "#b91c1c";
        return;
      }
      if (result?.ok) {
        status.textContent = "Unlocked. Reloading...";
        status.style.color = "#15803d";
        setTimeout(() => location.reload(), 350);
      } else {
        status.textContent = result?.error || "Unable to unlock extension.";
        status.style.color = "#b91c1c";
      }
    });
  });

  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") button.click();
  });

  card.append(title, description, input, button, status);
  overlay.appendChild(card);

  chrome.storage.local.get("extensionClaimed").then(({ extensionClaimed }) => {
    if (extensionClaimed !== true) document.body.appendChild(overlay);
  });
})();
