(() => {
  const panel = document.createElement("div");
  panel.id = "extension-claim-panel";
  panel.style.cssText = [
    "position:fixed",
    "top:20px",
    "right:20px",
    "z-index:9999",
    "width:320px",
    "padding:18px",
    "background:#ffffff",
    "border:1px solid #bfdbfe",
    "border-radius:12px",
    "box-shadow:0 8px 24px rgba(15,23,42,.16)",
    "font:13px/1.45 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif",
    "color:#172033"
  ].join(";");

  const title = document.createElement("strong");
  title.textContent = "Link extension to account";
  title.style.display = "block";

  const description = document.createElement("p");
  description.textContent = "Generate a code in the web app Settings page, then enter it here. The code expires after 10 minutes.";
  description.style.cssText = "margin:6px 0 12px;color:#64748b";

  const input = document.createElement("input");
  input.type = "text";
  input.placeholder = "Enter one-time code";
  input.autocomplete = "off";
  input.style.cssText = "box-sizing:border-box;width:100%;padding:9px 10px;border:1px solid #cbd5e1;border-radius:6px;text-transform:uppercase;letter-spacing:.12em";

  const button = document.createElement("button");
  button.type = "button";
  button.textContent = "Link extension";
  button.style.cssText = "margin-top:10px;width:100%;padding:9px 10px;border:0;border-radius:6px;background:#2563eb;color:white;font-weight:600;cursor:pointer";

  const status = document.createElement("p");
  status.style.cssText = "margin:8px 0 0;color:#64748b";

  button.addEventListener("click", () => {
    const code = input.value.trim().toUpperCase();
    if (!code) {
      status.textContent = "Enter a code first.";
      status.style.color = "#b91c1c";
      return;
    }
    button.disabled = true;
    button.style.opacity = ".6";
    status.textContent = "Linking...";
    status.style.color = "#64748b";
    chrome.runtime.sendMessage({ action: "claimExtension", code }, (result) => {
      button.disabled = false;
      button.style.opacity = "1";
      if (result?.ok) {
        status.textContent = "Extension linked successfully.";
        status.style.color = "#15803d";
        input.value = "";
      } else {
        status.textContent = result?.error || "Unable to link extension.";
        status.style.color = "#b91c1c";
      }
    });
  });

  panel.append(title, description, input, button, status);
  document.body.appendChild(panel);
})();
