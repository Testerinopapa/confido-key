function U(e) {
  let t = [];
  return [(n) => {
    let o = e;
    e = n;
    let a = t;
    for (; a[2] && (a = a[2], a[0](n, o), n === e); ) ;
  }, (n) => {
    let o = t;
    for (; o[2]; ) o = o[2];
    return o = o[2] = [n, o], () => {
      o && (o[1][2] = o[2], o = 0);
    };
  }, () => e];
}
const z = U("https://confido-key.lovable.app/api/public"), [$e, , g] = z, Q = U(""), [be, , M] = Q, m = {
  leads: "db:leads",
  messages: "db:msgs:",
  activity: "db:act:"
};
function J() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function T() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function C() {
  return (await chrome.storage.local.get(m.leads))[m.leads] || [];
}
async function Z(e) {
  return (await C()).filter((n) => n.status === e);
}
async function ee() {
  const e = await C(), t = { new: 0, connected: 0, messaged: 0, replied: 0, followup_due: 0, archived: 0 };
  for (const n of e) t[n.status] = (t[n.status] || 0) + 1;
  return t;
}
async function te() {
  return (await C()).filter((t) => t.status === "messaged").sort((t, n) => t.updatedAt.localeCompare(n.updatedAt));
}
async function A(e, t, n) {
  const o = await C(), a = o.find((r) => r.name === e);
  if (a)
    return a.headline = t || a.headline, a.profileUrl = n || a.profileUrl, a.updatedAt = T(), await chrome.storage.local.set({ [m.leads]: o }), a;
  const s = {
    id: J(),
    name: e,
    headline: t,
    profileUrl: n,
    status: "new",
    notes: "",
    createdAt: T(),
    updatedAt: T()
  };
  return o.push(s), await chrome.storage.local.set({ [m.leads]: o }), s;
}
async function D(e, t) {
  const n = await C(), o = n.find((a) => a.id === e);
  o && (o.status = t, o.updatedAt = T(), await chrome.storage.local.set({ [m.leads]: n }));
}
async function ne(e, t) {
  const n = await A(e, t, "");
  return await D(n.id, "connected"), n.status = "connected", n;
}
async function oe(e) {
  return (await chrome.storage.local.get(m.messages + e))[m.messages + e] || [];
}
async function W(e, t, n, o) {
  const a = await oe(e);
  a.push({ id: J(), leadId: e, direction: t, content: n, aiGenerated: o, createdAt: T() }), await chrome.storage.local.set({ [m.messages + e]: a });
}
function ae() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function Y() {
  const e = ae();
  return (await chrome.storage.local.get(m.activity + e))[m.activity + e] || { date: e, connectionsSent: 0, commentsMade: 0, postsCreated: 0, messagesSent: 0, messagesReceived: 0 };
}
async function f(e, t = 1) {
  const n = await Y();
  n[e] = n[e] + t, await chrome.storage.local.set({ [m.activity + n.date]: n });
}
async function se() {
  const e = [];
  for (let t = 6; t >= 0; t--) {
    const n = /* @__PURE__ */ new Date();
    n.setDate(n.getDate() - t);
    const o = n.toISOString().slice(0, 10), a = await chrome.storage.local.get(m.activity + o);
    e.push(a[m.activity + o] || { date: o, connectionsSent: 0, commentsMade: 0, postsCreated: 0, messagesSent: 0, messagesReceived: 0 });
  }
  return e;
}
function re() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
async function $() {
  const { deviceId: e } = await chrome.storage.local.get("deviceId");
  if (e) return e;
  const t = re();
  return await chrome.storage.local.set({ deviceId: t }), t;
}
async function O(e, t) {
  try {
    const n = g(), o = M(), a = await $(), s = await fetch(`${n}${e}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...o ? { "X-Api-Key": o } : {},
        "X-Device-Id": a
      },
      body: JSON.stringify(t)
    });
    s.ok || console.warn(`[sync] ${e} returned ${s.status}: ${await s.text()}`);
  } catch (n) {
    console.warn(`[sync] ${e} failed:`, n);
  }
}
async function ie(e, t) {
  try {
    const n = g(), o = M(), a = await $();
    await fetch(`${n}${e}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...o ? { "X-Api-Key": o } : {},
        "X-Device-Id": a
      },
      body: JSON.stringify(t)
    });
  } catch {
  }
}
async function b(e, t, n, o) {
  await O("/sync/lead", { name: e, headline: t, profile_url: n, status: o });
}
async function L(e, t, n, o) {
  await O("/sync/message", { lead_name: e, direction: t, content: n, ai_generated: o });
}
async function N(e) {
  await O("/sync/activity", e);
}
async function ce() {
  const e = M(), t = await $();
  return {
    "Content-Type": "application/json",
    ...e ? { "X-Api-Key": e } : {},
    "X-Device-Id": t
  };
}
async function le(e) {
  try {
    const t = await fetch(`${g()}${e}`, { headers: await ce() });
    return t.ok ? t.json() : null;
  } catch {
    return null;
  }
}
async function ue() {
  return await le("/sync/fingerprints") ?? { comments: [], posts: [] };
}
async function de(e, t) {
  await ie("/sync/fingerprints", { fingerprint: e, kind: t });
}
function w() {
  const e = M();
  return e ? { "Content-Type": "application/json", "X-Api-Key": e } : { "Content-Type": "application/json" };
}
let i = {
  isRunning: !1,
  count: 0,
  commentCount: 0,
  postCount: 0,
  messageCount: 0,
  firstMessageCount: 0,
  replyTarget: "",
  firstMessageTarget: "",
  connectTarget: "",
  commentTarget: "",
  recentNotes: [],
  postPreview: null
};
var F;
(F = chrome.sidePanel) != null && F.setPanelBehavior && chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch(() => {
});
function B(e) {
  if (e == null) return "";
  try {
    const t = JSON.stringify(e);
    return t === void 0 ? String(e) : t;
  } catch {
    try {
      return String(e);
    } catch {
      return "(unserializable)";
    }
  }
}
async function me(e) {
  const t = g().trim().replace(/\/+$/, ""), n = await $(), o = await fetch(`${t}/claim`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Device-Id": n
    },
    body: JSON.stringify({ code: e.trim().toUpperCase() })
  }), a = await o.json().catch(() => ({}));
  if (!o.ok)
    throw new Error((a == null ? void 0 : a.error) || `Claim failed (${o.status})`);
  return await chrome.storage.local.set({ extensionClaimed: !0 }), a;
}
chrome.runtime.onMessage.addListener((e, t, n) => {
  var o, a, s;
  if (e.action !== "getState" && console.log(`[${t.tab ? "tab" : "popup"}]`, e.action, B(e.data ?? e)), e.action === "debug") {
    console.log(`  [tab debug] ${e.msg}`, B(e.data));
    return;
  }
  if (e.action === "getClaimStatus")
    return chrome.storage.local.get("extensionClaimed", ({ extensionClaimed: r }) => {
      n({ claimed: r === !0 });
    }), !0;
  if (e.action === "claimExtension")
    return me(String(e.code || "")).then(() => n({ ok: !0 })).catch((r) => n({ ok: !1, error: r instanceof Error ? r.message : "Claim failed" })), !0;
  if (e.action === "getState") {
    n(i);
    return;
  }
  if (e.action === "stateUpdated") {
    i = { ...i, isRunning: e.isRunning, count: e.count, commentCount: e.commentCount ?? i.commentCount, postCount: e.postCount ?? i.postCount, messageCount: e.messageCount ?? i.messageCount, firstMessageCount: e.firstMessageCount ?? i.firstMessageCount, replyTarget: e.replyTarget ?? i.replyTarget, firstMessageTarget: e.firstMessageTarget ?? i.firstMessageTarget, connectTarget: e.connectTarget ?? i.connectTarget, commentTarget: e.commentTarget ?? i.commentTarget };
    return;
  }
  if ((e.action === "start" || e.action === "stop") && chrome.tabs.query({ active: !0, currentWindow: !0 }, ([r]) => {
    r != null && r.id && chrome.tabs.sendMessage(r.id, e).catch(() => {
      console.log("[sw] tab not reachable — is the content script loaded on this page?");
    });
  }), e.action === "generateNote")
    return we(e.profile).then(n).catch(() => n("")), !0;
  if (e.action === "generateFirstMessage")
    return Ce(e.profile).then(n).catch(() => n("")), !0;
  if (e.action === "generateComment")
    return Te(e.post).then(n).catch(() => n("")), !0;
  if (e.action === "generateReply")
    return ke(e.conversation).then(n).catch(() => n("")), !0;
  if (e.action === "generatePostContent")
    return ve(e.topic, e.imagePrompt).then(n).catch(() => n({})), !0;
  if (e.action === "noteGenerated" && (i.recentNotes = [...i.recentNotes, { name: e.name, note: e.note }], i.recentNotes.length > 10 && i.recentNotes.shift()), e.action === "postPreview") {
    i.postPreview = { text: e.text, imageBase64: e.imageBase64, imageMimeType: e.imageMimeType };
    return;
  }
  if (e.action === "postPreviewCleared") {
    i.postPreview = null;
    return;
  }
  if (e.action === "cdpClick") {
    xe((o = t.tab) == null ? void 0 : o.id, e.x, e.y).catch(() => {
    });
    return;
  }
  if (e.action === "cdpPaste") {
    Me((a = t.tab) == null ? void 0 : a.id).catch(() => {
    });
    return;
  }
  if (e.action === "cdpEscape") {
    De((s = t.tab) == null ? void 0 : s.id).catch(() => {
    });
    return;
  }
  if (e.action === "reportConnected" && ge(e.data).catch(() => {
  }), e.action === "reportMessaged" && he(e.data).catch(() => {
  }), e.action === "reportReplied" && ye(e.data).catch(() => {
  }), e.action === "reportFirstMessaged" && pe(e.data).catch(() => {
  }), e.action === "reportActivity" && fe(e.data).catch(() => {
  }), e.action === "getFingerprints")
    return ue().then(n).catch(() => n({ comments: [], posts: [] })), !0;
  if (e.action === "syncFingerprint") {
    de(e.fingerprint, e.kind);
    return;
  }
  if (e.action === "getPipeline" || e.action === "getDailyStats" || e.action === "getWeeklyStats" || e.action === "getUnreplied" || e.action === "getLeadsByStatus")
    return Se(e.action, e.data).then(n).catch(() => n(null)), !0;
});
async function ge(e) {
  await ne(e.name, e.headline), await f("connectionsSent"), b(e.name, e.headline, "", "connected"), N({ connections_sent: 1 });
}
async function he(e) {
  const t = await A(e.name, e.headline, e.profileUrl);
  t.status !== "replied" && await D(t.id, "messaged"), await f("messagesReceived"), b(e.name, e.headline, e.profileUrl, "messaged"), L(e.name, "inbound", e.headline || "", !1), N({ messages_received: 1 });
}
async function ye(e) {
  i.recentNotes = [...i.recentNotes, { name: e.name, note: e.replyText }], i.recentNotes.length > 10 && i.recentNotes.shift();
  const n = (await C()).find((o) => o.name === e.name);
  n && (await D(n.id, "replied"), await W(n.id, "outbound", e.replyText, !0)), b(e.name, "", "", "replied"), L(e.name, "outbound", e.replyText, !0), N({ messages_sent: 1 });
}
async function pe(e) {
  i.recentNotes = [...i.recentNotes, { name: e.name, note: e.messageText }], i.recentNotes.length > 10 && i.recentNotes.shift();
  const t = await A(e.name, "", "");
  t.status !== "replied" && await D(t.id, "messaged"), await W(t.id, "outbound", e.messageText, !1), await b(e.name, "", "", "messaged"), await L(e.name, "outbound", e.messageText, !1);
}
async function fe(e) {
  e.connections && await f("connectionsSent", e.connections), e.comments && await f("commentsMade", e.comments), e.posts && await f("postsCreated", e.posts), e.messagesSent && await f("messagesSent", e.messagesSent), e.messagesReceived && await f("messagesReceived", e.messagesReceived), N({
    connections_sent: e.connections ?? 0,
    comments_made: e.comments ?? 0,
    posts_created: e.posts ?? 0,
    messages_sent: e.messagesSent ?? 0,
    messages_received: e.messagesReceived ?? 0
  });
}
async function k(e) {
  const t = await chrome.storage.sync.get(e);
  return typeof t[e] == "string" ? t[e].trim() : "";
}
async function we(e) {
  var o, a, s;
  console.log("[sw] calling Claude via proxy for", e.name || "(no name)");
  const t = await k("connectInstruction"), n = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 150,
    system: "You write personalized LinkedIn connection notes. Be concise and genuine. Never use placeholders like [Name] or [Company]." + (t ? ` Follow this guidance: ${t}` : ""),
    messages: [{ role: "user", content: `Write ONE short, friendly LinkedIn connection note to ${e.name || "this person"} (${e.headline || "no headline available"}). Natural, not salesy, under 250 chars. No placeholders.` }]
  };
  try {
    const r = await fetch(`${g()}/claude`, {
      method: "POST",
      headers: w(),
      body: JSON.stringify(n)
    });
    if (!r.ok) {
      const y = await r.json().catch(() => ({ error: `HTTP ${r.status}` }));
      return console.error("[sw] Proxy Claude error", y.error || r.status), "";
    }
    const c = await r.json(), d = ((s = (a = (o = c == null ? void 0 : c.content) == null ? void 0 : o[0]) == null ? void 0 : a.text) == null ? void 0 : s.trim()) || "";
    return console.log("[sw] Proxy Claude response text length:", d.length), d;
  } catch (r) {
    return console.log("[sw] Proxy Claude error", r), "";
  }
}
async function Ce(e) {
  var o, a, s;
  console.log("[sw] calling Claude via proxy for first message to", e.name || "(unknown)");
  const t = await k("connectionsInstruction"), n = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 150,
    system: "You write short, genuine LinkedIn messages to your existing connections to start a conversation. Be friendly and natural, not salesy." + (t ? ` Follow this guidance: ${t}` : ""),
    messages: [{ role: "user", content: `Write ONE short, friendly opening message to ${e.name || "this connection"} to start a conversation. Natural, not salesy, under 250 chars.` }]
  };
  try {
    const r = await fetch(`${g()}/claude`, {
      method: "POST",
      headers: w(),
      body: JSON.stringify(n)
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({ error: `HTTP ${r.status}` }));
      return console.error("[sw] Proxy Claude error", d.error || r.status), "";
    }
    const c = await r.json();
    return ((s = (a = (o = c == null ? void 0 : c.content) == null ? void 0 : o[0]) == null ? void 0 : a.text) == null ? void 0 : s.trim()) || "";
  } catch (r) {
    return console.log("[sw] Proxy Claude first-message error", r), "";
  }
}
async function Te(e) {
  var o, a, s;
  console.log("[sw] calling Claude via proxy for comment on post by", e.author || "(no author)");
  const t = await k("commentInstruction"), n = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 200,
    system: "You write thoughtful, genuine LinkedIn comments on posts. Be concise and relevant to the post content. Never use generic praise like 'Great post!' or 'Thanks for sharing!'. Write something specific that shows you read the post." + (t ? ` Follow this guidance: ${t}` : ""),
    messages: [{ role: "user", content: `Write ONE short, genuine comment on this LinkedIn post by ${e.author || "someone"}.

Post content:
"${e.text.substring(0, 500)}"

Make it specific to what they wrote, under 300 chars. Conversational and natural, not salesy.` }]
  };
  try {
    const r = await fetch(`${g()}/claude`, {
      method: "POST",
      headers: w(),
      body: JSON.stringify(n)
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({ error: `HTTP ${r.status}` }));
      return console.error("[sw] Proxy Claude error", d.error || r.status), "";
    }
    const c = await r.json();
    return ((s = (a = (o = c == null ? void 0 : c.content) == null ? void 0 : o[0]) == null ? void 0 : a.text) == null ? void 0 : s.trim()) || "";
  } catch (r) {
    return console.log("[sw] Proxy Claude error", r), "";
  }
}
async function ke(e) {
  var a, s, r;
  console.log("[sw] calling Claude via proxy for reply to", e.correspondent || "(unknown)");
  const t = e.lastMessages.map((c) => `${c.sender}: ${c.text}`).join(`
`), n = await k("messagingInstruction"), o = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 200,
    system: "You are a busy professional replying to LinkedIn DMs. You are direct, confident, and never waffle. You write like you speak — short sentences, no fluff. Never use: 'I'd love to', 'Happy to', 'Great question', 'That's a great', 'I appreciate', 'Thank you for', 'I'm excited', 'Let's connect', 'I'd be happy', 'Would love to'. No exclamation marks. No emoji. No sign-offs like 'Best' or 'Cheers'. Never acknowledge you're an AI, never apologize for not being able to do something. Just give a straight answer like a real person would." + (n ? ` Follow this guidance: ${n}` : ""),
    messages: [{
      role: "user",
      content: `Reply to ${e.correspondent || "this person"}${e.headline ? ` (${e.headline})` : ""}.

Messages:
${t || "(no previous messages)"}

Under 200 chars. One message only.`
    }]
  };
  try {
    const c = await fetch(`${g()}/claude`, {
      method: "POST",
      headers: w(),
      body: JSON.stringify(o)
    });
    if (!c.ok) {
      const v = await c.json().catch(() => ({ error: `HTTP ${c.status}` }));
      return console.error("[sw] Proxy Claude error", v.error || c.status), "";
    }
    const d = await c.json(), y = ((r = (s = (a = d == null ? void 0 : d.content) == null ? void 0 : a[0]) == null ? void 0 : s.text) == null ? void 0 : r.trim()) || "";
    return console.log("[sw] Proxy Claude reply generated, length:", y.length), y;
  } catch (c) {
    return console.log("[sw] Proxy Claude reply error", c), "";
  }
}
async function ve(e, t) {
  var c, d, y, v, E, K, _, H, j;
  const n = await k("postInstruction"), o = [
    "Generate both a short LinkedIn post and a relevant professional image.",
    `Post topic: ${e || "industry trends"}`,
    "Write 2-3 sentences that show expertise, under 500 characters.",
    t ? `Image direction: ${t}` : "Create a relevant image to accompany the post.",
    n ? `Post writing guidance: ${n}` : "",
    "Return the post text and image together."
  ].filter(Boolean).join(`

`);
  let a, s, r;
  try {
    console.log("[sw] calling Gemini via proxy for post generation");
    const l = await fetch(`${g()}/gemini`, {
      method: "POST",
      headers: w(),
      body: JSON.stringify({
        model: "gemini-3.1-flash-image-preview",
        action: "generateContent",
        contents: [{ parts: [{ text: o }] }],
        generationConfig: { responseModalities: ["IMAGE", "TEXT"] }
      })
    });
    if (l.ok) {
      const u = await l.json(), p = ((y = (d = (c = u == null ? void 0 : u.candidates) == null ? void 0 : c[0]) == null ? void 0 : d.content) == null ? void 0 : y.parts) || [];
      for (const h of p)
        h.inlineData && (a = h.inlineData.data, s = h.inlineData.mimeType || "image/png"), h.text && typeof h.text == "string" && h.text.length > 10 && (r = h.text);
      console.log("[sw] Proxy Gemini response:", { hasImage: !!a, hasText: !!r });
    } else {
      const u = await l.json().catch(() => ({ error: `HTTP ${l.status}` }));
      console.error("[sw] Proxy Gemini error", u.error || l.status);
    }
  } catch (l) {
    console.log("[sw] Proxy Gemini error", l);
  }
  if (!a)
    try {
      const l = [
        "Generate one professional image for a LinkedIn post.",
        `Topic: ${e || "industry trends"}`,
        t ? `Image direction: ${t}` : "Use a clean, relevant visual that supports the topic.",
        n ? `Keep the visual aligned with this post guidance: ${n}` : "",
        "Return image data."
      ].filter(Boolean).join(`

`), u = await fetch(`${g()}/gemini`, {
        method: "POST",
        headers: w(),
        body: JSON.stringify({
          model: "gemini-3.1-flash-image-preview",
          action: "generateContent",
          contents: [{ parts: [{ text: l }] }],
          generationConfig: { responseModalities: ["IMAGE"] }
        })
      });
      if (u.ok) {
        const p = await u.json(), I = (((K = (E = (v = p == null ? void 0 : p.candidates) == null ? void 0 : v[0]) == null ? void 0 : E.content) == null ? void 0 : K.parts) || []).find((q) => {
          var G;
          return (G = q.inlineData) == null ? void 0 : G.data;
        });
        I && (a = I.inlineData.data, s = I.inlineData.mimeType || "image/png");
      } else {
        const p = await u.json().catch(() => ({ error: `HTTP ${u.status}` }));
        console.error("[sw] Proxy Gemini image retry error", p.error || u.status);
      }
    } catch (l) {
      console.log("[sw] Proxy Gemini image retry error", l);
    }
  if (!r)
    try {
      console.log("[sw] falling back to Claude via proxy for post text");
      const l = await fetch(`${g()}/claude`, {
        method: "POST",
        headers: w(),
        body: JSON.stringify({
          model: "claude-haiku-4-5-20251001",
          max_tokens: 200,
          system: "You write professional LinkedIn posts. Be concise and insightful. No hashtags unless they flow naturally." + (n ? ` Follow this guidance: ${n}` : ""),
          messages: [{ role: "user", content: `Write a short, professional LinkedIn post about ${e || "industry trends"}. 2-3 sentences, under 500 chars. Natural tone.` }]
        })
      });
      if (l.ok) {
        const u = await l.json();
        r = ((j = (H = (_ = u == null ? void 0 : u.content) == null ? void 0 : _[0]) == null ? void 0 : H.text) == null ? void 0 : j.trim()) || "", console.log("[sw] Proxy Claude post text generated, length:", (r || "").length);
      } else {
        const u = await l.json().catch(() => ({ error: `HTTP ${l.status}` }));
        console.error("[sw] Proxy Claude error", u.error || l.status);
      }
    } catch (l) {
      console.log("[sw] Proxy Claude post text error", l);
    }
  return { imageBase64: a, imageMimeType: s, text: r };
}
async function Se(e, t) {
  switch (e) {
    case "getPipeline":
      return ee();
    case "getDailyStats":
      return Y();
    case "getWeeklyStats":
      return se();
    case "getUnreplied":
      return te();
    case "getLeadsByStatus":
      return Z(t.status);
    default:
      return null;
  }
}
chrome.alarms.create("midnight", { when: Pe(), periodInMinutes: 1440 });
function Pe() {
  const e = /* @__PURE__ */ new Date();
  return new Date(e.getFullYear(), e.getMonth(), e.getDate() + 1).getTime();
}
const S = "autoComment";
chrome.storage.onChanged.addListener((e) => {
  (e.autoCommentDaily || e.commentScheduleHour) && V(), (e.autoPostDaily || e.postScheduleHour) && R(), (e.autoMessageDaily || e.messageScheduleHour) && X();
});
async function V() {
  const { autoCommentDaily: e, commentScheduleHour: t } = await chrome.storage.sync.get({
    autoCommentDaily: !1,
    commentScheduleHour: "9"
  }), n = await chrome.alarms.get(S);
  if (e) {
    const o = Number(t) || 9, a = /* @__PURE__ */ new Date(), s = new Date(a.getFullYear(), a.getMonth(), a.getDate(), o, 7, 0);
    s.getTime() <= a.getTime() && s.setDate(s.getDate() + 1), (!n || n.scheduledTime !== s.getTime()) && (chrome.alarms.create(S, {
      when: s.getTime(),
      periodInMinutes: 1440
    }), console.log("[sw] auto-comment alarm set for", s.toLocaleString()));
  } else
    n && (chrome.alarms.clear(S), console.log("[sw] auto-comment alarm cleared"));
}
const P = "autoPost";
async function R() {
  const { autoPostDaily: e, postScheduleHour: t } = await chrome.storage.sync.get({
    autoPostDaily: !1,
    postScheduleHour: "10"
  }), n = await chrome.alarms.get(P);
  if (e) {
    const o = Number(t) || 10, a = /* @__PURE__ */ new Date(), s = new Date(a.getFullYear(), a.getMonth(), a.getDate(), o, 13, 0);
    s.getTime() <= a.getTime() && s.setDate(s.getDate() + 1), (!n || n.scheduledTime !== s.getTime()) && (chrome.alarms.create(P, {
      when: s.getTime(),
      periodInMinutes: 1440
    }), console.log("[sw] auto-post alarm set for", s.toLocaleString()));
  } else
    n && (chrome.alarms.clear(P), console.log("[sw] auto-post alarm cleared"));
}
chrome.alarms.onAlarm.addListener(async (e) => {
  if (e.name === "midnight" && (chrome.storage.local.remove("dailyConnectionCount"), chrome.storage.local.remove("dailyCommentCount"), chrome.storage.local.remove("dailyPostCount"), chrome.storage.local.remove("dailyMessageCount"), i = { ...i, count: 0, commentCount: 0, postCount: 0, messageCount: 0 }, console.log("[sw] midnight reset — daily counts cleared")), e.name === S) {
    console.log("[sw] auto-comment alarm fired");
    const { commentSearchKeyword: t } = await chrome.storage.sync.get({ commentSearchKeyword: "" }), n = t || "", o = n ? `https://www.linkedin.com/search/results/content/?keywords=${encodeURIComponent(n)}` : "https://www.linkedin.com/search/results/content/";
    chrome.tabs.create({ url: o }, (a) => {
      if (a != null && a.id) {
        const s = a.id;
        setTimeout(() => {
          chrome.tabs.sendMessage(s, { action: "start" }).catch(() => {
            console.log("[sw] auto-comment: tab not ready yet");
          }), i = { ...i, isRunning: !0 };
        }, 5e3);
      }
    });
  }
  e.name === P && (console.log("[sw] auto-post alarm fired"), chrome.tabs.create({ url: "https://www.linkedin.com/feed/" }, (t) => {
    if (t != null && t.id) {
      const n = t.id;
      setTimeout(() => {
        chrome.tabs.sendMessage(n, { action: "start" }).catch(() => {
          console.log("[sw] auto-post: tab not ready yet");
        }), i = { ...i, isRunning: !0 };
      }, 5e3);
    }
  })), e.name === x && (console.log("[sw] auto-message alarm fired"), chrome.tabs.create({ url: "https://www.linkedin.com/messaging/" }, (t) => {
    if (t != null && t.id) {
      const n = t.id;
      setTimeout(() => {
        chrome.tabs.sendMessage(n, { action: "start" }).catch(() => {
          console.log("[sw] auto-message: tab not ready yet");
        }), i = { ...i, isRunning: !0 };
      }, 5e3);
    }
  }));
});
const x = "autoMessage";
async function X() {
  const { autoMessageDaily: e, messageScheduleHour: t } = await chrome.storage.sync.get({
    autoMessageDaily: !1,
    messageScheduleHour: "9"
  }), n = await chrome.alarms.get(x);
  if (e) {
    const o = Number(t) || 9, a = /* @__PURE__ */ new Date(), s = new Date(a.getFullYear(), a.getMonth(), a.getDate(), o, 23, 0);
    s.getTime() <= a.getTime() && s.setDate(s.getDate() + 1), (!n || n.scheduledTime !== s.getTime()) && (chrome.alarms.create(x, {
      when: s.getTime(),
      periodInMinutes: 1440
    }), console.log("[sw] auto-message alarm set for", s.toLocaleString()));
  } else
    n && (chrome.alarms.clear(x), console.log("[sw] auto-message alarm cleared"));
}
V();
R();
X();
async function xe(e, t, n) {
  if (!e) {
    console.log("[sw] cdpClick: no tabId");
    return;
  }
  try {
    await chrome.debugger.attach({ tabId: e }, "1.3"), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchMouseEvent", {
      type: "mouseMoved",
      x: t,
      y: n,
      pointerType: "mouse"
    }), await new Promise((o) => setTimeout(o, 50)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      x: t,
      y: n,
      button: "left",
      clickCount: 1,
      pointerType: "mouse"
    }), await new Promise((o) => setTimeout(o, 80 + Math.random() * 120)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x: t,
      y: n,
      button: "left",
      clickCount: 1,
      pointerType: "mouse"
    }), console.log(`[sw] CDP click dispatched at (${Math.round(t)}, ${Math.round(n)})`);
  } catch (o) {
    console.log("[sw] CDP click failed:", o.message);
  } finally {
    chrome.debugger.detach({ tabId: e }).catch(() => {
    });
  }
}
async function Me(e) {
  if (!e) {
    console.log("[sw] cdpPaste: no tabId");
    return;
  }
  try {
    await chrome.debugger.attach({ tabId: e }, "1.3"), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "Control",
      code: "ControlLeft",
      keyCode: 17,
      windowsVirtualKeyCode: 17
    }), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "v",
      code: "KeyV",
      keyCode: 86,
      modifiers: 2,
      windowsVirtualKeyCode: 86
    }), await new Promise((t) => setTimeout(t, 30 + Math.random() * 40)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "v",
      code: "KeyV",
      keyCode: 86,
      modifiers: 2,
      windowsVirtualKeyCode: 86
    }), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "Control",
      code: "ControlLeft",
      keyCode: 17,
      windowsVirtualKeyCode: 17
    }), console.log("[sw] CDP paste dispatched");
  } catch (t) {
    console.log("[sw] CDP paste failed:", t.message);
  } finally {
    chrome.debugger.detach({ tabId: e }).catch(() => {
    });
  }
}
async function De(e) {
  if (!e) {
    console.log("[sw] cdpEscape: no tabId");
    return;
  }
  try {
    await chrome.debugger.attach({ tabId: e }, "1.3"), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "Escape",
      code: "Escape",
      keyCode: 27,
      windowsVirtualKeyCode: 27,
      nativeVirtualKeyCode: 27
    }), await new Promise((t) => setTimeout(t, 50)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "Escape",
      code: "Escape",
      keyCode: 27,
      windowsVirtualKeyCode: 27,
      nativeVirtualKeyCode: 27
    }), console.log("[sw] CDP Escape dispatched");
  } catch (t) {
    console.log("[sw] CDP Escape failed:", t.message);
  } finally {
    chrome.debugger.detach({ tabId: e }).catch(() => {
    });
  }
}
