function F(e) {
  let t = [];
  return [(n) => {
    let o = e;
    e = n;
    let a = t;
    for (; a[2] && (a = a[2], a[0](n, o), n === e); ) ;
  }, (n) => {
    let o = t;
    for (; o[2]; ) o = o[2];
    return o = o[2] = [n, o], () => {
      o && (o[1][2] = o[2], o = 0);
    };
  }, () => e];
}
const Y = F("https://confido-key.lovable.app/api/public"), [Se, , g] = Y, V = F(""), [Pe, , x] = V, d = {
  leads: "db:leads",
  messages: "db:msgs:",
  activity: "db:act:"
};
function H() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function C() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function w() {
  return (await chrome.storage.local.get(d.leads))[d.leads] || [];
}
async function X(e) {
  return (await w()).filter((n) => n.status === e);
}
async function R() {
  const e = await w(), t = { new: 0, connected: 0, messaged: 0, replied: 0, followup_due: 0, archived: 0 };
  for (const n of e) t[n.status] = (t[n.status] || 0) + 1;
  return t;
}
async function z() {
  return (await w()).filter((t) => t.status === "messaged").sort((t, n) => t.updatedAt.localeCompare(n.updatedAt));
}
async function N(e, t, n) {
  const o = await w(), a = o.find((r) => r.name === e);
  if (a)
    return a.headline = t || a.headline, a.profileUrl = n || a.profileUrl, a.updatedAt = C(), await chrome.storage.local.set({ [d.leads]: o }), a;
  const s = {
    id: H(),
    name: e,
    headline: t,
    profileUrl: n,
    status: "new",
    notes: "",
    createdAt: C(),
    updatedAt: C()
  };
  return o.push(s), await chrome.storage.local.set({ [d.leads]: o }), s;
}
async function M(e, t) {
  const n = await w(), o = n.find((a) => a.id === e);
  o && (o.status = t, o.updatedAt = C(), await chrome.storage.local.set({ [d.leads]: n }));
}
async function q(e, t) {
  const n = await N(e, t, "");
  return await M(n.id, "connected"), n.status = "connected", n;
}
async function Q(e) {
  return (await chrome.storage.local.get(d.messages + e))[d.messages + e] || [];
}
async function U(e, t, n, o) {
  const a = await Q(e);
  a.push({ id: H(), leadId: e, direction: t, content: n, aiGenerated: o, createdAt: C() }), await chrome.storage.local.set({ [d.messages + e]: a });
}
function Z() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function j() {
  const e = Z();
  return (await chrome.storage.local.get(d.activity + e))[d.activity + e] || { date: e, connectionsSent: 0, commentsMade: 0, postsCreated: 0, messagesSent: 0, messagesReceived: 0 };
}
async function p(e, t = 1) {
  const n = await j();
  n[e] = n[e] + t, await chrome.storage.local.set({ [d.activity + n.date]: n });
}
async function ee() {
  const e = [];
  for (let t = 6; t >= 0; t--) {
    const n = /* @__PURE__ */ new Date();
    n.setDate(n.getDate() - t);
    const o = n.toISOString().slice(0, 10), a = await chrome.storage.local.get(d.activity + o);
    e.push(a[d.activity + o] || { date: o, connectionsSent: 0, commentsMade: 0, postsCreated: 0, messagesSent: 0, messagesReceived: 0 });
  }
  return e;
}
function te() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
async function D() {
  const { deviceId: e } = await chrome.storage.local.get("deviceId");
  if (e) return e;
  const t = te();
  return await chrome.storage.local.set({ deviceId: t }), t;
}
async function A(e, t) {
  try {
    const n = g(), o = x(), a = await D(), s = await fetch(`${n}${e}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...o ? { "X-Api-Key": o } : {},
        "X-Device-Id": a
      },
      body: JSON.stringify(t)
    });
    s.ok || console.warn(`[sync] ${e} returned ${s.status}: ${await s.text()}`);
  } catch (n) {
    console.warn(`[sync] ${e} failed:`, n);
  }
}
async function ne(e, t) {
  try {
    const n = g(), o = x(), a = await D();
    await fetch(`${n}${e}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...o ? { "X-Api-Key": o } : {},
        "X-Device-Id": a
      },
      body: JSON.stringify(t)
    });
  } catch {
  }
}
async function b(e, t, n, o) {
  await A("/sync/lead", { name: e, headline: t, profile_url: n, status: o });
}
async function I(e, t, n, o) {
  await A("/sync/message", { lead_name: e, direction: t, content: n, ai_generated: o });
}
async function $(e) {
  await A("/sync/activity", e);
}
async function oe() {
  const e = x(), t = await D();
  return {
    "Content-Type": "application/json",
    ...e ? { "X-Api-Key": e } : {},
    "X-Device-Id": t
  };
}
async function ae(e) {
  try {
    const t = await fetch(`${g()}${e}`, { headers: await oe() });
    return t.ok ? t.json() : null;
  } catch {
    return null;
  }
}
async function se() {
  return await ae("/sync/fingerprints") ?? { comments: [], posts: [] };
}
async function re(e, t) {
  await ne("/sync/fingerprints", { fingerprint: e, kind: t });
}
function f() {
  const e = x();
  return e ? { "Content-Type": "application/json", "X-Api-Key": e } : { "Content-Type": "application/json" };
}
let i = {
  isRunning: !1,
  count: 0,
  commentCount: 0,
  postCount: 0,
  messageCount: 0,
  firstMessageCount: 0,
  replyTarget: "",
  firstMessageTarget: "",
  connectTarget: "",
  commentTarget: "",
  recentNotes: [],
  postPreview: null
};
var _;
(_ = chrome.sidePanel) != null && _.setPanelBehavior && chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch(() => {
});
function K(e) {
  if (e == null) return "";
  try {
    const t = JSON.stringify(e);
    return t === void 0 ? String(e) : t;
  } catch {
    try {
      return String(e);
    } catch {
      return "(unserializable)";
    }
  }
}
async function ie(e) {
  const t = g().trim().replace(/\/+$/, ""), n = await D(), o = await fetch(`${t}/claim`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Device-Id": n
    },
    body: JSON.stringify({ code: e.trim().toUpperCase() })
  }), a = await o.json().catch(() => ({}));
  if (!o.ok)
    throw new Error((a == null ? void 0 : a.error) || `Claim failed (${o.status})`);
  return await chrome.storage.local.set({ extensionClaimed: !0 }), a;
}
chrome.runtime.onMessage.addListener((e, t, n) => {
  var o, a, s;
  if (e.action !== "getState" && console.log(`[${t.tab ? "tab" : "popup"}]`, e.action, K(e.data ?? e)), e.action === "debug") {
    console.log(`  [tab debug] ${e.msg}`, K(e.data));
    return;
  }
  if (e.action === "getClaimStatus")
    return chrome.storage.local.get("extensionClaimed", ({ extensionClaimed: r }) => {
      n({ claimed: r === !0 });
    }), !0;
  if (e.action === "claimExtension")
    return ie(String(e.code || "")).then(() => n({ ok: !0 })).catch((r) => n({ ok: !1, error: r instanceof Error ? r.message : "Claim failed" })), !0;
  if (e.action === "getState") {
    n(i);
    return;
  }
  if (e.action === "stateUpdated") {
    i = { ...i, isRunning: e.isRunning, count: e.count, commentCount: e.commentCount ?? i.commentCount, postCount: e.postCount ?? i.postCount, messageCount: e.messageCount ?? i.messageCount, firstMessageCount: e.firstMessageCount ?? i.firstMessageCount, replyTarget: e.replyTarget ?? i.replyTarget, firstMessageTarget: e.firstMessageTarget ?? i.firstMessageTarget, connectTarget: e.connectTarget ?? i.connectTarget, commentTarget: e.commentTarget ?? i.commentTarget };
    return;
  }
  if ((e.action === "start" || e.action === "stop") && chrome.tabs.query({ active: !0, currentWindow: !0 }, ([r]) => {
    r != null && r.id && chrome.tabs.sendMessage(r.id, e).catch(() => {
      console.log("[sw] tab not reachable — is the content script loaded on this page?");
    });
  }), e.action === "generateNote")
    return ge(e.profile).then(n).catch(() => n("")), !0;
  if (e.action === "generateFirstMessage")
    return he(e.profile).then(n).catch(() => n("")), !0;
  if (e.action === "generateComment")
    return ye(e.post).then(n).catch(() => n("")), !0;
  if (e.action === "generateReply")
    return pe(e.conversation).then(n).catch(() => n("")), !0;
  if (e.action === "generatePostContent")
    return fe(e.topic, e.imagePrompt).then(n).catch(() => n({})), !0;
  if (e.action === "noteGenerated" && (i.recentNotes = [...i.recentNotes, { name: e.name, note: e.note }], i.recentNotes.length > 10 && i.recentNotes.shift()), e.action === "postPreview") {
    i.postPreview = { text: e.text, imageBase64: e.imageBase64, imageMimeType: e.imageMimeType };
    return;
  }
  if (e.action === "postPreviewCleared") {
    i.postPreview = null;
    return;
  }
  if (e.action === "cdpClick") {
    Te((o = t.tab) == null ? void 0 : o.id, e.x, e.y).catch(() => {
    });
    return;
  }
  if (e.action === "cdpPaste") {
    ke((a = t.tab) == null ? void 0 : a.id).catch(() => {
    });
    return;
  }
  if (e.action === "cdpEscape") {
    ve((s = t.tab) == null ? void 0 : s.id).catch(() => {
    });
    return;
  }
  if (e.action === "reportConnected" && ce(e.data).catch(() => {
  }), e.action === "reportMessaged" && le(e.data).catch(() => {
  }), e.action === "reportReplied" && ue(e.data).catch(() => {
  }), e.action === "reportFirstMessaged" && de(e.data).catch(() => {
  }), e.action === "reportActivity" && me(e.data).catch(() => {
  }), e.action === "getFingerprints")
    return se().then(n).catch(() => n({ comments: [], posts: [] })), !0;
  if (e.action === "syncFingerprint") {
    re(e.fingerprint, e.kind);
    return;
  }
  if (e.action === "getPipeline" || e.action === "getDailyStats" || e.action === "getWeeklyStats" || e.action === "getUnreplied" || e.action === "getLeadsByStatus")
    return we(e.action, e.data).then(n).catch(() => n(null)), !0;
});
async function ce(e) {
  await q(e.name, e.headline), await p("connectionsSent"), b(e.name, e.headline, "", "connected"), $({ connections_sent: 1 });
}
async function le(e) {
  const t = await N(e.name, e.headline, e.profileUrl);
  t.status !== "replied" && await M(t.id, "messaged"), await p("messagesReceived"), b(e.name, e.headline, e.profileUrl, "messaged"), I(e.name, "inbound", e.headline || "", !1), $({ messages_received: 1 });
}
async function ue(e) {
  i.recentNotes = [...i.recentNotes, { name: e.name, note: e.replyText }], i.recentNotes.length > 10 && i.recentNotes.shift();
  const n = (await w()).find((o) => o.name === e.name);
  n && (await M(n.id, "replied"), await U(n.id, "outbound", e.replyText, !0)), b(e.name, "", "", "replied"), I(e.name, "outbound", e.replyText, !0), $({ messages_sent: 1 });
}
async function de(e) {
  i.recentNotes = [...i.recentNotes, { name: e.name, note: e.messageText }], i.recentNotes.length > 10 && i.recentNotes.shift();
  const t = await N(e.name, "", "");
  t.status !== "replied" && await M(t.id, "messaged"), await U(t.id, "outbound", e.messageText, !1), await b(e.name, "", "", "messaged"), await I(e.name, "outbound", e.messageText, !1);
}
async function me(e) {
  e.connections && await p("connectionsSent", e.connections), e.comments && await p("commentsMade", e.comments), e.posts && await p("postsCreated", e.posts), e.messagesSent && await p("messagesSent", e.messagesSent), e.messagesReceived && await p("messagesReceived", e.messagesReceived), $({
    connections_sent: e.connections ?? 0,
    comments_made: e.comments ?? 0,
    posts_created: e.posts ?? 0,
    messages_sent: e.messagesSent ?? 0,
    messages_received: e.messagesReceived ?? 0
  });
}
async function T(e) {
  const t = await chrome.storage.sync.get(e);
  return typeof t[e] == "string" ? t[e].trim() : "";
}
async function ge(e) {
  var o, a, s;
  console.log("[sw] calling Claude via proxy for", e.name || "(no name)");
  const t = await T("connectInstruction"), n = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 150,
    system: "You write personalized LinkedIn connection notes. Be concise and genuine. Never use placeholders like [Name] or [Company]." + (t ? ` Follow this guidance: ${t}` : ""),
    messages: [{ role: "user", content: `Write ONE short, friendly LinkedIn connection note to ${e.name || "this person"} (${e.headline || "no headline available"}). Natural, not salesy, under 250 chars. No placeholders.` }]
  };
  try {
    const r = await fetch(`${g()}/claude`, {
      method: "POST",
      headers: f(),
      body: JSON.stringify(n)
    });
    if (!r.ok) {
      const h = await r.json().catch(() => ({ error: `HTTP ${r.status}` }));
      return console.error("[sw] Proxy Claude error", h.error || r.status), "";
    }
    const c = await r.json(), u = ((s = (a = (o = c == null ? void 0 : c.content) == null ? void 0 : o[0]) == null ? void 0 : a.text) == null ? void 0 : s.trim()) || "";
    return console.log("[sw] Proxy Claude response text length:", u.length), u;
  } catch (r) {
    return console.log("[sw] Proxy Claude error", r), "";
  }
}
async function he(e) {
  var o, a, s;
  console.log("[sw] calling Claude via proxy for first message to", e.name || "(unknown)");
  const t = await T("connectionsInstruction"), n = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 150,
    system: "You write short, genuine LinkedIn messages to your existing connections to start a conversation. Be friendly and natural, not salesy." + (t ? ` Follow this guidance: ${t}` : ""),
    messages: [{ role: "user", content: `Write ONE short, friendly opening message to ${e.name || "this connection"} to start a conversation. Natural, not salesy, under 250 chars.` }]
  };
  try {
    const r = await fetch(`${g()}/claude`, {
      method: "POST",
      headers: f(),
      body: JSON.stringify(n)
    });
    if (!r.ok) {
      const u = await r.json().catch(() => ({ error: `HTTP ${r.status}` }));
      return console.error("[sw] Proxy Claude error", u.error || r.status), "";
    }
    const c = await r.json();
    return ((s = (a = (o = c == null ? void 0 : c.content) == null ? void 0 : o[0]) == null ? void 0 : a.text) == null ? void 0 : s.trim()) || "";
  } catch (r) {
    return console.log("[sw] Proxy Claude first-message error", r), "";
  }
}
async function ye(e) {
  var o, a, s;
  console.log("[sw] calling Claude via proxy for comment on post by", e.author || "(no author)");
  const t = await T("commentInstruction"), n = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 200,
    system: "You write thoughtful, genuine LinkedIn comments on posts. Be concise and relevant to the post content. Never use generic praise like 'Great post!' or 'Thanks for sharing!'. Write something specific that shows you read the post." + (t ? ` Follow this guidance: ${t}` : ""),
    messages: [{ role: "user", content: `Write ONE short, genuine comment on this LinkedIn post by ${e.author || "someone"}.

Post content:
"${e.text.substring(0, 500)}"

Make it specific to what they wrote, under 300 chars. Conversational and natural, not salesy.` }]
  };
  try {
    const r = await fetch(`${g()}/claude`, {
      method: "POST",
      headers: f(),
      body: JSON.stringify(n)
    });
    if (!r.ok) {
      const u = await r.json().catch(() => ({ error: `HTTP ${r.status}` }));
      return console.error("[sw] Proxy Claude error", u.error || r.status), "";
    }
    const c = await r.json();
    return ((s = (a = (o = c == null ? void 0 : c.content) == null ? void 0 : o[0]) == null ? void 0 : a.text) == null ? void 0 : s.trim()) || "";
  } catch (r) {
    return console.log("[sw] Proxy Claude error", r), "";
  }
}
async function pe(e) {
  var a, s, r;
  console.log("[sw] calling Claude via proxy for reply to", e.correspondent || "(unknown)");
  const t = e.lastMessages.map((c) => `${c.sender}: ${c.text}`).join(`
`), n = await T("messagingInstruction"), o = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 200,
    system: "You are a busy professional replying to LinkedIn DMs. You are direct, confident, and never waffle. You write like you speak — short sentences, no fluff. Never use: 'I'd love to', 'Happy to', 'Great question', 'That's a great', 'I appreciate', 'Thank you for', 'I'm excited', 'Let's connect', 'I'd be happy', 'Would love to'. No exclamation marks. No emoji. No sign-offs like 'Best' or 'Cheers'. Never acknowledge you're an AI, never apologize for not being able to do something. Just give a straight answer like a real person would." + (n ? ` Follow this guidance: ${n}` : ""),
    messages: [{
      role: "user",
      content: `Reply to ${e.correspondent || "this person"}${e.headline ? ` (${e.headline})` : ""}.

Messages:
${t || "(no previous messages)"}

Under 200 chars. One message only.`
    }]
  };
  try {
    const c = await fetch(`${g()}/claude`, {
      method: "POST",
      headers: f(),
      body: JSON.stringify(o)
    });
    if (!c.ok) {
      const k = await c.json().catch(() => ({ error: `HTTP ${c.status}` }));
      return console.error("[sw] Proxy Claude error", k.error || c.status), "";
    }
    const u = await c.json(), h = ((r = (s = (a = u == null ? void 0 : u.content) == null ? void 0 : a[0]) == null ? void 0 : s.text) == null ? void 0 : r.trim()) || "";
    return console.log("[sw] Proxy Claude reply generated, length:", h.length), h;
  } catch (c) {
    return console.log("[sw] Proxy Claude reply error", c), "";
  }
}
async function fe(e, t) {
  var u, h, k, O, L, E;
  const n = await T("postInstruction"), o = t || `Write a short, professional LinkedIn post about ${e || "industry trends"}. Include 2-3 sentences that show expertise. Under 500 characters. Also generate a relevant, professional image to accompany the post.`, a = n ? `${o}

Follow this user guidance: ${n}` : o;
  let s, r, c;
  try {
    console.log("[sw] calling Gemini via proxy for post generation");
    const l = await fetch(`${g()}/gemini`, {
      method: "POST",
      headers: f(),
      body: JSON.stringify({
        model: "gemini-3.1-flash-image-preview",
        action: "generateContent",
        contents: [{ parts: [{ text: a }] }],
        generationConfig: { responseModalities: ["IMAGE", "TEXT"] }
      })
    });
    if (l.ok) {
      const m = await l.json(), W = ((k = (h = (u = m == null ? void 0 : m.candidates) == null ? void 0 : u[0]) == null ? void 0 : h.content) == null ? void 0 : k.parts) || [];
      for (const y of W)
        y.inlineData && (s = y.inlineData.data, r = y.inlineData.mimeType || "image/png"), y.text && typeof y.text == "string" && y.text.length > 10 && (c = y.text);
      console.log("[sw] Proxy Gemini response:", { hasImage: !!s, hasText: !!c });
    } else {
      const m = await l.json().catch(() => ({ error: `HTTP ${l.status}` }));
      console.error("[sw] Proxy Gemini error", m.error || l.status);
    }
  } catch (l) {
    console.log("[sw] Proxy Gemini error", l);
  }
  if (!c)
    try {
      console.log("[sw] falling back to Claude via proxy for post text");
      const l = await fetch(`${g()}/claude`, {
        method: "POST",
        headers: f(),
        body: JSON.stringify({
          model: "claude-haiku-4-5-20251001",
          max_tokens: 200,
          system: "You write professional LinkedIn posts. Be concise and insightful. No hashtags unless they flow naturally." + (n ? ` Follow this guidance: ${n}` : ""),
          messages: [{ role: "user", content: `Write a short, professional LinkedIn post about ${e || "industry trends"}. 2-3 sentences, under 500 chars. Natural tone.` }]
        })
      });
      if (l.ok) {
        const m = await l.json();
        c = ((E = (L = (O = m == null ? void 0 : m.content) == null ? void 0 : O[0]) == null ? void 0 : L.text) == null ? void 0 : E.trim()) || "", console.log("[sw] Proxy Claude post text generated, length:", (c || "").length);
      } else {
        const m = await l.json().catch(() => ({ error: `HTTP ${l.status}` }));
        console.error("[sw] Proxy Claude error", m.error || l.status);
      }
    } catch (l) {
      console.log("[sw] Proxy Claude post text error", l);
    }
  return { imageBase64: s, imageMimeType: r, text: c };
}
async function we(e, t) {
  switch (e) {
    case "getPipeline":
      return R();
    case "getDailyStats":
      return j();
    case "getWeeklyStats":
      return ee();
    case "getUnreplied":
      return z();
    case "getLeadsByStatus":
      return X(t.status);
    default:
      return null;
  }
}
chrome.alarms.create("midnight", { when: Ce(), periodInMinutes: 1440 });
function Ce() {
  const e = /* @__PURE__ */ new Date();
  return new Date(e.getFullYear(), e.getMonth(), e.getDate() + 1).getTime();
}
const v = "autoComment";
chrome.storage.onChanged.addListener((e) => {
  (e.autoCommentDaily || e.commentScheduleHour) && B(), (e.autoPostDaily || e.postScheduleHour) && G(), (e.autoMessageDaily || e.messageScheduleHour) && J();
});
async function B() {
  const { autoCommentDaily: e, commentScheduleHour: t } = await chrome.storage.sync.get({
    autoCommentDaily: !1,
    commentScheduleHour: "9"
  }), n = await chrome.alarms.get(v);
  if (e) {
    const o = Number(t) || 9, a = /* @__PURE__ */ new Date(), s = new Date(a.getFullYear(), a.getMonth(), a.getDate(), o, 7, 0);
    s.getTime() <= a.getTime() && s.setDate(s.getDate() + 1), (!n || n.scheduledTime !== s.getTime()) && (chrome.alarms.create(v, {
      when: s.getTime(),
      periodInMinutes: 1440
    }), console.log("[sw] auto-comment alarm set for", s.toLocaleString()));
  } else
    n && (chrome.alarms.clear(v), console.log("[sw] auto-comment alarm cleared"));
}
const S = "autoPost";
async function G() {
  const { autoPostDaily: e, postScheduleHour: t } = await chrome.storage.sync.get({
    autoPostDaily: !1,
    postScheduleHour: "10"
  }), n = await chrome.alarms.get(S);
  if (e) {
    const o = Number(t) || 10, a = /* @__PURE__ */ new Date(), s = new Date(a.getFullYear(), a.getMonth(), a.getDate(), o, 13, 0);
    s.getTime() <= a.getTime() && s.setDate(s.getDate() + 1), (!n || n.scheduledTime !== s.getTime()) && (chrome.alarms.create(S, {
      when: s.getTime(),
      periodInMinutes: 1440
    }), console.log("[sw] auto-post alarm set for", s.toLocaleString()));
  } else
    n && (chrome.alarms.clear(S), console.log("[sw] auto-post alarm cleared"));
}
chrome.alarms.onAlarm.addListener(async (e) => {
  if (e.name === "midnight" && (chrome.storage.local.remove("dailyConnectionCount"), chrome.storage.local.remove("dailyCommentCount"), chrome.storage.local.remove("dailyPostCount"), chrome.storage.local.remove("dailyMessageCount"), i = { ...i, count: 0, commentCount: 0, postCount: 0, messageCount: 0 }, console.log("[sw] midnight reset — daily counts cleared")), e.name === v) {
    console.log("[sw] auto-comment alarm fired");
    const { commentSearchKeyword: t } = await chrome.storage.sync.get({ commentSearchKeyword: "" }), n = t || "", o = n ? `https://www.linkedin.com/search/results/content/?keywords=${encodeURIComponent(n)}` : "https://www.linkedin.com/search/results/content/";
    chrome.tabs.create({ url: o }, (a) => {
      if (a != null && a.id) {
        const s = a.id;
        setTimeout(() => {
          chrome.tabs.sendMessage(s, { action: "start" }).catch(() => {
            console.log("[sw] auto-comment: tab not ready yet");
          }), i = { ...i, isRunning: !0 };
        }, 5e3);
      }
    });
  }
  e.name === S && (console.log("[sw] auto-post alarm fired"), chrome.tabs.create({ url: "https://www.linkedin.com/feed/" }, (t) => {
    if (t != null && t.id) {
      const n = t.id;
      setTimeout(() => {
        chrome.tabs.sendMessage(n, { action: "start" }).catch(() => {
          console.log("[sw] auto-post: tab not ready yet");
        }), i = { ...i, isRunning: !0 };
      }, 5e3);
    }
  })), e.name === P && (console.log("[sw] auto-message alarm fired"), chrome.tabs.create({ url: "https://www.linkedin.com/messaging/" }, (t) => {
    if (t != null && t.id) {
      const n = t.id;
      setTimeout(() => {
        chrome.tabs.sendMessage(n, { action: "start" }).catch(() => {
          console.log("[sw] auto-message: tab not ready yet");
        }), i = { ...i, isRunning: !0 };
      }, 5e3);
    }
  }));
});
const P = "autoMessage";
async function J() {
  const { autoMessageDaily: e, messageScheduleHour: t } = await chrome.storage.sync.get({
    autoMessageDaily: !1,
    messageScheduleHour: "9"
  }), n = await chrome.alarms.get(P);
  if (e) {
    const o = Number(t) || 9, a = /* @__PURE__ */ new Date(), s = new Date(a.getFullYear(), a.getMonth(), a.getDate(), o, 23, 0);
    s.getTime() <= a.getTime() && s.setDate(s.getDate() + 1), (!n || n.scheduledTime !== s.getTime()) && (chrome.alarms.create(P, {
      when: s.getTime(),
      periodInMinutes: 1440
    }), console.log("[sw] auto-message alarm set for", s.toLocaleString()));
  } else
    n && (chrome.alarms.clear(P), console.log("[sw] auto-message alarm cleared"));
}
B();
G();
J();
async function Te(e, t, n) {
  if (!e) {
    console.log("[sw] cdpClick: no tabId");
    return;
  }
  try {
    await chrome.debugger.attach({ tabId: e }, "1.3"), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchMouseEvent", {
      type: "mouseMoved",
      x: t,
      y: n,
      pointerType: "mouse"
    }), await new Promise((o) => setTimeout(o, 50)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      x: t,
      y: n,
      button: "left",
      clickCount: 1,
      pointerType: "mouse"
    }), await new Promise((o) => setTimeout(o, 80 + Math.random() * 120)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x: t,
      y: n,
      button: "left",
      clickCount: 1,
      pointerType: "mouse"
    }), console.log(`[sw] CDP click dispatched at (${Math.round(t)}, ${Math.round(n)})`);
  } catch (o) {
    console.log("[sw] CDP click failed:", o.message);
  } finally {
    chrome.debugger.detach({ tabId: e }).catch(() => {
    });
  }
}
async function ke(e) {
  if (!e) {
    console.log("[sw] cdpPaste: no tabId");
    return;
  }
  try {
    await chrome.debugger.attach({ tabId: e }, "1.3"), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "Control",
      code: "ControlLeft",
      keyCode: 17,
      windowsVirtualKeyCode: 17
    }), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "v",
      code: "KeyV",
      keyCode: 86,
      modifiers: 2,
      windowsVirtualKeyCode: 86
    }), await new Promise((t) => setTimeout(t, 30 + Math.random() * 40)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "v",
      code: "KeyV",
      keyCode: 86,
      modifiers: 2,
      windowsVirtualKeyCode: 86
    }), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "Control",
      code: "ControlLeft",
      keyCode: 17,
      windowsVirtualKeyCode: 17
    }), console.log("[sw] CDP paste dispatched");
  } catch (t) {
    console.log("[sw] CDP paste failed:", t.message);
  } finally {
    chrome.debugger.detach({ tabId: e }).catch(() => {
    });
  }
}
async function ve(e) {
  if (!e) {
    console.log("[sw] cdpEscape: no tabId");
    return;
  }
  try {
    await chrome.debugger.attach({ tabId: e }, "1.3"), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "Escape",
      code: "Escape",
      keyCode: 27,
      windowsVirtualKeyCode: 27,
      nativeVirtualKeyCode: 27
    }), await new Promise((t) => setTimeout(t, 50)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "Escape",
      code: "Escape",
      keyCode: 27,
      windowsVirtualKeyCode: 27,
      nativeVirtualKeyCode: 27
    }), console.log("[sw] CDP Escape dispatched");
  } catch (t) {
    console.log("[sw] CDP Escape failed:", t.message);
  } finally {
    chrome.debugger.detach({ tabId: e }).catch(() => {
    });
  }
}
