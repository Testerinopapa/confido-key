function _(e) {
  let t = [];
  return [(n) => {
    let o = e;
    e = n;
    let a = t;
    for (; a[2] && (a = a[2], a[0](n, o), n === e); ) ;
  }, (n) => {
    let o = t;
    for (; o[2]; ) o = o[2];
    return o = o[2] = [n, o], () => {
      o && (o[1][2] = o[2], o = 0);
    };
  }, () => e];
}
const W = _("https://confido-key.lovable.app/api/public"), [ke, , g] = W, Y = _(""), [ve, , M] = Y, d = {
  leads: "db:leads",
  messages: "db:msgs:",
  activity: "db:act:"
};
function H() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function C() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function w() {
  return (await chrome.storage.local.get(d.leads))[d.leads] || [];
}
async function V(e) {
  return (await w()).filter((n) => n.status === e);
}
async function R() {
  const e = await w(), t = { new: 0, connected: 0, messaged: 0, replied: 0, followup_due: 0, archived: 0 };
  for (const n of e) t[n.status] = (t[n.status] || 0) + 1;
  return t;
}
async function X() {
  return (await w()).filter((t) => t.status === "messaged").sort((t, n) => t.updatedAt.localeCompare(n.updatedAt));
}
async function $(e, t, n) {
  const o = await w(), a = o.find((r) => r.name === e);
  if (a)
    return a.headline = t || a.headline, a.profileUrl = n || a.profileUrl, a.updatedAt = C(), await chrome.storage.local.set({ [d.leads]: o }), a;
  const s = {
    id: H(),
    name: e,
    headline: t,
    profileUrl: n,
    status: "new",
    notes: "",
    createdAt: C(),
    updatedAt: C()
  };
  return o.push(s), await chrome.storage.local.set({ [d.leads]: o }), s;
}
async function x(e, t) {
  const n = await w(), o = n.find((a) => a.id === e);
  o && (o.status = t, o.updatedAt = C(), await chrome.storage.local.set({ [d.leads]: n }));
}
async function z(e, t) {
  const n = await $(e, t, "");
  return await x(n.id, "connected"), n.status = "connected", n;
}
async function q(e) {
  return (await chrome.storage.local.get(d.messages + e))[d.messages + e] || [];
}
async function F(e, t, n, o) {
  const a = await q(e);
  a.push({ id: H(), leadId: e, direction: t, content: n, aiGenerated: o, createdAt: C() }), await chrome.storage.local.set({ [d.messages + e]: a });
}
function localDateKey(e = /* @__PURE__ */ new Date()) {
  return [e.getFullYear(), e.getMonth() + 1, e.getDate()].map((t, n) => n === 0 ? String(t) : String(t).padStart(2, "0")).join("-");
}
function Q() {
  return localDateKey();
}
async function B() {
  const e = Q();
  return (await chrome.storage.local.get(d.activity + e))[d.activity + e] || { date: e, connectionsSent: 0, commentsMade: 0, postsCreated: 0, messagesSent: 0, messagesReceived: 0 };
}
async function p(e, t = 1) {
  const n = await B();
  n[e] = n[e] + t, await chrome.storage.local.set({ [d.activity + n.date]: n });
}
async function Z() {
  const e = [];
  for (let t = 6; t >= 0; t--) {
    const n = /* @__PURE__ */ new Date();
    n.setDate(n.getDate() - t);
    const o = localDateKey(n), a = await chrome.storage.local.get(d.activity + o);
    e.push(a[d.activity + o] || { date: o, connectionsSent: 0, commentsMade: 0, postsCreated: 0, messagesSent: 0, messagesReceived: 0 });
  }
  return e;
}
function ee() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
let deviceIdPromise;
async function N() {
  if (!deviceIdPromise) {
    deviceIdPromise = (async () => {
      const { deviceId: e } = await chrome.storage.local.get("deviceId");
      if (e) return e;
      const t = crypto.randomUUID?.() || ee();
      await chrome.storage.local.set({ deviceId: t });
      return t;
    })().catch((e) => {
      deviceIdPromise = null;
      throw e;
    });
  }
  return deviceIdPromise;
}
function normalizeServiceBase(e) {
  const t = String(e || "").trim().replace(/\/+$/, "");
  return /\/api\/public$/i.test(t) ? t : `${t}/api/public`;
}
const SYNC_QUEUE_KEY = "syncQueue";
let syncFlushPromise = null;
function syncId() {
  return crypto.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
async function sendSync(e, t) {
  const n = normalizeServiceBase(g()), a = await N(), s = await fetch(`${n}${e}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Device-Id": a
    },
    body: JSON.stringify(t)
  });
  if (!s.ok) {
    const r = new Error(`HTTP ${s.status}: ${await s.text()}`);
    r.status = s.status;
    throw r;
  }
}
function shouldRetrySync(e) {
  return !e?.status || e.status === 401 || e.status === 404 || e.status === 429 || e.status >= 500;
}
async function queueSync(e) {
  const { [SYNC_QUEUE_KEY]: t } = await chrome.storage.local.get(SYNC_QUEUE_KEY), n = Array.isArray(t) ? t : [];
  n.push(e), n.length > 500 && n.splice(0, n.length - 500), await chrome.storage.local.set({ [SYNC_QUEUE_KEY]: n });
}
async function flushSyncQueue() {
  if (syncFlushPromise) return syncFlushPromise;
  return syncFlushPromise = (async () => {
    const { [SYNC_QUEUE_KEY]: e } = await chrome.storage.local.get(SYNC_QUEUE_KEY), t = Array.isArray(e) ? e : [], n = [];
    for (const o of t)
      try {
        await sendSync(o.path, o.payload);
      } catch (a) {
        shouldRetrySync(a) && n.push(o);
      }
    await chrome.storage.local.set({ [SYNC_QUEUE_KEY]: n });
  })().finally(() => {
    syncFlushPromise = null;
  }), syncFlushPromise;
}
async function A(e, t) {
  const n = syncId(), a = /* @__PURE__ */ new Date(), s = { id: n, path: e, payload: { ...t, event_id: n, occurred_at: a.toISOString(), occurred_date: localDateKey(a) } };
  try {
    await sendSync(s.path, s.payload);
  } catch (r) {
    if (shouldRetrySync(r))
      try {
        await queueSync(s);
        console.warn(`[sync] ${e} failed; queued for retry:`, r);
      } catch (o) {
        console.warn(`[sync] ${e} failed and could not be queued:`, o);
      }
    else {
      console.warn(`[sync] ${e} rejected and was not queued:`, r);
    }
  }
  flushSyncQueue().catch((r) => console.warn("[sync] retry flush failed:", r));
}
async function claimDevice(e) {
  const n = normalizeServiceBase(g()), a = await N(), s = await fetch(`${n}/claim`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Device-Id": a
    },
    body: JSON.stringify({ code: e })
  }), t = await s.json().catch(() => ({}));
  if (!s.ok) throw new Error(t.error || `Claim failed (${s.status})`);
  return await chrome.storage.local.set({ extensionClaimed: !0 }), flushSyncQueue().catch(() => {
  }), t;
}
async function isExtensionClaimed() {
  const { extensionClaimed: e } = await chrome.storage.local.get("extensionClaimed");
  return e === true;
}
function guardedResponse(e, t, n) {
  isExtensionClaimed().then(async (o) => {
    if (!o) {
      e({ ok: !1, locked: !0, error: "Extension is locked. Enter an unlock code first." });
      return;
    }
    try {
      e(await t());
    } catch {
      e(n);
    }
  }).catch(() => e(n));
  return true;
}
function runIfClaimed(e) {
  isExtensionClaimed().then((t) => {
    if (t) e();
  }).catch(() => {
  });
}
async function te(e, t) {
  await A(e, t);
}
async function D(e, t, n, o) {
  await A("/sync/lead", { name: e, headline: t, profile_url: n, status: o });
}
async function I(e, t, n, o) {
  await A("/sync/message", { lead_name: e, direction: t, content: n, ai_generated: o });
}
async function b(e) {
  await A("/sync/activity", e);
}
async function ne() {
  const t = await N();
  return {
    "Content-Type": "application/json",
    "X-Device-Id": t
  };
}
async function oe(e) {
  try {
    const t = await fetch(`${normalizeServiceBase(g())}${e}`, { headers: await ne() });
    return t.ok ? t.json() : null;
  } catch {
    return null;
  }
}
async function ae() {
  return await oe("/sync/fingerprints") ?? { comments: [], posts: [] };
}
async function se(e, t) {
  await te("/sync/fingerprints", { fingerprint: e, kind: t });
}
function f() {
  return { "Content-Type": "application/json" };
}
let i = {
  isRunning: !1,
  count: 0,
  commentCount: 0,
  postCount: 0,
  messageCount: 0,
  firstMessageCount: 0,
  replyTarget: "",
  firstMessageTarget: "",
  connectTarget: "",
  commentTarget: "",
  recentNotes: [],
  postPreview: null
};
var K;
(K = chrome.sidePanel) != null && K.setPanelBehavior && chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch(() => {
});
function E(e) {
  if (e == null) return "";
  try {
    const t = JSON.stringify(e);
    return t === void 0 ? String(e) : t;
  } catch {
    try {
      return String(e);
    } catch {
      return "(unserializable)";
    }
  }
}
chrome.runtime.onMessage.addListener((e, t, n) => {
  var o, a, s;
  if (e.action !== "getState" && console.log(`[${t.tab ? "tab" : "popup"}]`, e.action, E(e.data ?? e)), e.action === "debug") {
    console.log(`  [tab debug] ${e.msg}`, E(e.data));
    return;
  }
  if (e.action === "getClaimStatus") {
    isExtensionClaimed().then((r) => n({ claimed: r })).catch(() => n({ claimed: false }));
    return true;
  }
  if (e.action === "claimExtension") {
    claimDevice(e.code).then(() => n({ ok: !0 })).catch((r) => n({ ok: !1, error: r.message }));
    return true;
  }
  if (e.action === "getState") {
    n(i);
    return;
  }
  if (e.action === "stateUpdated") {
    i = { ...i, isRunning: e.isRunning, count: e.count, commentCount: e.commentCount ?? i.commentCount, postCount: e.postCount ?? i.postCount, messageCount: e.messageCount ?? i.messageCount, firstMessageCount: e.firstMessageCount ?? i.firstMessageCount, replyTarget: e.replyTarget ?? i.replyTarget, firstMessageTarget: e.firstMessageTarget ?? i.firstMessageTarget, connectTarget: e.connectTarget ?? i.connectTarget, commentTarget: e.commentTarget ?? i.commentTarget };
    return;
  }
  if (e.action === "start") {
    runIfClaimed(() => chrome.tabs.query({ active: !0, currentWindow: !0 }, ([r]) => {
      r != null && r.id && chrome.tabs.sendMessage(r.id, e).catch(() => {
        console.log("[sw] tab not reachable â€” is the content script loaded on this page?");
      });
    }));
    return true;
  }
  if ((e.action === "start" || e.action === "stop") && chrome.tabs.query({ active: !0, currentWindow: !0 }, ([r]) => {
    r != null && r.id && chrome.tabs.sendMessage(r.id, e).catch(() => {
      console.log("[sw] tab not reachable — is the content script loaded on this page?");
    });
  }), e.action === "generateNote")
    return guardedResponse(n, () => de(e.profile), "");
  if (e.action === "generateFirstMessage")
    return guardedResponse(n, () => me(e.profile), "");
  if (e.action === "generateComment")
    return guardedResponse(n, () => ge(e.post), "");
  if (e.action === "generateReply")
    return guardedResponse(n, () => he(e.conversation), "");
  if (e.action === "generatePostContent")
    return guardedResponse(n, () => ye(e.topic, e.imagePrompt), {});
  if (e.action === "noteGenerated" && (i.recentNotes = [...i.recentNotes, { name: e.name, note: e.note }], i.recentNotes.length > 10 && i.recentNotes.shift()), e.action === "postPreview") {
    i.postPreview = { text: e.text, imageBase64: e.imageBase64, imageMimeType: e.imageMimeType };
    return;
  }
  if (e.action === "postPreviewCleared") {
    i.postPreview = null;
    return;
  }
  if (e.action === "cdpClick") {
    runIfClaimed(() => we((o = t.tab) == null ? void 0 : o.id, e.x, e.y).catch(() => {
    }));
    return;
  }
  if (e.action === "cdpPaste") {
    runIfClaimed(() => Ce((a = t.tab) == null ? void 0 : a.id).catch(() => {
    }));
    return;
  }
  if (e.action === "cdpEscape") {
    runIfClaimed(() => Te((s = t.tab) == null ? void 0 : s.id).catch(() => {
    }));
    return;
  }
  if (e.action === "reportConnected") {
    return guardedResponse(n, () => re(e.data).then(() => ({ ok: !0 })), { ok: !1 });
  }
  if (e.action === "reportActivity") {
    return guardedResponse(n, () => ue(e.data).then(() => ({ ok: !0 })), { ok: !1 });
  }
  if (e.action === "reportMessaged") {
    return guardedResponse(n, () => ie(e.data).then(() => ({ ok: !0 })), { ok: !1 });
  }
  if (e.action === "reportReplied") {
    return guardedResponse(n, () => ce(e.data).then(() => ({ ok: !0 })), { ok: !1 });
  }
  if (e.action === "reportFirstMessaged") {
    return guardedResponse(n, () => le(e.data).then(() => ({ ok: !0 })), { ok: !1 });
  }
  if (e.action === "getFingerprints")
    return guardedResponse(n, () => ae(), { comments: [], posts: [] });
  if (e.action === "syncFingerprint") {
    runIfClaimed(() => se(e.fingerprint, e.kind));
    return;
  }
  if (e.action === "getPipeline" || e.action === "getDailyStats" || e.action === "getWeeklyStats" || e.action === "getUnreplied" || e.action === "getLeadsByStatus")
    return pe(e.action, e.data).then(n).catch(() => n(null)), !0;
});
async function re(e) {
  await z(e.name, e.headline), await p("connectionsSent"), await D(e.name, e.headline, "", "connected"), await b({ connections_sent: 1 });
}
async function ie(e) {
  const t = await $(e.name, e.headline, e.profileUrl);
  t.status !== "replied" && await x(t.id, "messaged"), await p("messagesReceived"), await D(e.name, e.headline, e.profileUrl, "messaged"), await I(e.name, "inbound", e.headline || "", !1), await b({ messages_received: 1 });
}
async function ce(e) {
  i.recentNotes = [...i.recentNotes, { name: e.name, note: e.replyText }], i.recentNotes.length > 10 && i.recentNotes.shift();
  const n = (await w()).find((o) => o.name === e.name);
  n && (await x(n.id, "replied"), await F(n.id, "outbound", e.replyText, !0)), await D(e.name, "", "", "replied"), await I(e.name, "outbound", e.replyText, !0), await b({ messages_sent: 1 });
}
async function le(e) {
  i.recentNotes = [...i.recentNotes, { name: e.name, note: e.messageText }], i.recentNotes.length > 10 && i.recentNotes.shift();
  const t = await $(e.name, "", "");
  t.status !== "replied" && await x(t.id, "messaged"), await F(t.id, "outbound", e.messageText, !1), await D(e.name, "", "", "messaged"), await I(e.name, "outbound", e.messageText, !1);
}
async function ue(e) {
  e.connections && await p("connectionsSent", e.connections), e.comments && await p("commentsMade", e.comments), e.posts && await p("postsCreated", e.posts), e.messagesSent && await p("messagesSent", e.messagesSent), e.messagesReceived && await p("messagesReceived", e.messagesReceived), await b({
    connections_sent: e.connections ?? 0,
    comments_made: e.comments ?? 0,
    posts_created: e.posts ?? 0,
    messages_sent: e.messagesSent ?? 0,
    messages_received: e.messagesReceived ?? 0
  });
}
async function T(e) {
  const t = await chrome.storage.sync.get(e);
  return typeof t[e] == "string" ? t[e].trim() : "";
}
async function de(e) {
  var o, a, s;
  console.log("[sw] calling Claude via proxy for", e.name || "(no name)");
  const t = await T("connectInstruction"), n = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 150,
    system: "You write personalized LinkedIn connection notes. Be concise and genuine. Never use placeholders like [Name] or [Company]." + (t ? ` Follow this guidance: ${t}` : ""),
    messages: [{ role: "user", content: `Write ONE short, friendly LinkedIn connection note to ${e.name || "this person"} (${e.headline || "no headline available"}). Natural, not salesy, under 250 chars. No placeholders.` }]
  };
  try {
    const r = await fetch(`${normalizeServiceBase(g())}/claude`, {
      method: "POST",
      headers: f(),
      body: JSON.stringify(n)
    });
    if (!r.ok) {
      const h = await r.json().catch(() => ({ error: `HTTP ${r.status}` }));
      return console.error("[sw] Proxy Claude error", h.error || r.status), "";
    }
    const c = await r.json(), u = ((s = (a = (o = c == null ? void 0 : c.content) == null ? void 0 : o[0]) == null ? void 0 : a.text) == null ? void 0 : s.trim()) || "";
    return console.log("[sw] Proxy Claude response text length:", u.length), u;
  } catch (r) {
    return console.log("[sw] Proxy Claude error", r), "";
  }
}
async function me(e) {
  var o, a, s;
  console.log("[sw] calling Claude via proxy for first message to", e.name || "(unknown)");
  const t = await T("connectionsInstruction"), n = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 150,
    system: "You write short, genuine LinkedIn messages to your existing connections to start a conversation. Be friendly and natural, not salesy." + (t ? ` Follow this guidance: ${t}` : ""),
    messages: [{ role: "user", content: `Write ONE short, friendly opening message to ${e.name || "this connection"} to start a conversation. Natural, not salesy, under 250 chars.` }]
  };
  try {
    const r = await fetch(`${normalizeServiceBase(g())}/claude`, {
      method: "POST",
      headers: f(),
      body: JSON.stringify(n)
    });
    if (!r.ok) {
      const u = await r.json().catch(() => ({ error: `HTTP ${r.status}` }));
      return console.error("[sw] Proxy Claude error", u.error || r.status), "";
    }
    const c = await r.json();
    return ((s = (a = (o = c == null ? void 0 : c.content) == null ? void 0 : o[0]) == null ? void 0 : a.text) == null ? void 0 : s.trim()) || "";
  } catch (r) {
    return console.log("[sw] Proxy Claude first-message error", r), "";
  }
}
async function ge(e) {
  var o, a, s;
  console.log("[sw] calling Claude via proxy for comment on post by", e.author || "(no author)");
  const t = await T("commentInstruction"), n = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 200,
    system: "You write thoughtful, genuine LinkedIn comments on posts. Be concise and relevant to the post content. Never use generic praise like 'Great post!' or 'Thanks for sharing!'. Write something specific that shows you read the post." + (t ? ` Follow this guidance: ${t}` : ""),
    messages: [{ role: "user", content: `Write ONE short, genuine comment on this LinkedIn post by ${e.author || "someone"}.

Post content:
"${e.text.substring(0, 500)}"

Make it specific to what they wrote, under 300 chars. Conversational and natural, not salesy.` }]
  };
  try {
    const r = await fetch(`${normalizeServiceBase(g())}/claude`, {
      method: "POST",
      headers: f(),
      body: JSON.stringify(n)
    });
    if (!r.ok) {
      const u = await r.json().catch(() => ({ error: `HTTP ${r.status}` }));
      return console.error("[sw] Proxy Claude error", u.error || r.status), "";
    }
    const c = await r.json();
    return ((s = (a = (o = c == null ? void 0 : c.content) == null ? void 0 : o[0]) == null ? void 0 : a.text) == null ? void 0 : s.trim()) || "";
  } catch (r) {
    return console.log("[sw] Proxy Claude error", r), "";
  }
}
async function he(e) {
  var a, s, r;
  console.log("[sw] calling Claude via proxy for reply to", e.correspondent || "(unknown)");
  const t = e.lastMessages.map((c) => `${c.sender}: ${c.text}`).join(`
`), n = await T("messagingInstruction"), o = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 200,
    system: "You are a busy professional replying to LinkedIn DMs. You are direct, confident, and never waffle. You write like you speak — short sentences, no fluff. Never use: 'I'd love to', 'Happy to', 'Great question', 'That's a great', 'I appreciate', 'Thank you for', 'I'm excited', 'Let's connect', 'I'd be happy', 'Would love to'. No exclamation marks. No emoji. No sign-offs like 'Best' or 'Cheers'. Never acknowledge you're an AI, never apologize for not being able to do something. Just give a straight answer like a real person would." + (n ? ` Follow this guidance: ${n}` : ""),
    messages: [{
      role: "user",
      content: `Reply to ${e.correspondent || "this person"}${e.headline ? ` (${e.headline})` : ""}.

Messages:
${t || "(no previous messages)"}

Under 200 chars. One message only.`
    }]
  };
  try {
    const c = await fetch(`${normalizeServiceBase(g())}/claude`, {
      method: "POST",
      headers: f(),
      body: JSON.stringify(o)
    });
    if (!c.ok) {
      const k = await c.json().catch(() => ({ error: `HTTP ${c.status}` }));
      return console.error("[sw] Proxy Claude error", k.error || c.status), "";
    }
    const u = await c.json(), h = ((r = (s = (a = u == null ? void 0 : u.content) == null ? void 0 : a[0]) == null ? void 0 : s.text) == null ? void 0 : r.trim()) || "";
    return console.log("[sw] Proxy Claude reply generated, length:", h.length), h;
  } catch (c) {
    return console.log("[sw] Proxy Claude reply error", c), "";
  }
}
async function ye(e, t) {
  var c, u, h, k, L, O;
  const n = await T("postInstruction"), o = t || `Write a short, professional LinkedIn post about ${e || "industry trends"}. Include 2-3 sentences that show expertise. Under 500 characters. Also generate a relevant, professional image to accompany the post.`;
  let a, s, r;
  try {
    console.log("[sw] calling Gemini via proxy for post generation");
    const l = await fetch(`${normalizeServiceBase(g())}/gemini`, {
      method: "POST",
      headers: f(),
      body: JSON.stringify({
        model: "gemini-3.1-flash-image-preview",
        action: "generateContent",
        contents: [{ parts: [{ text: o }] }],
        generationConfig: { responseModalities: ["IMAGE", "TEXT"] }
      })
    });
    if (l.ok) {
      const m = await l.json(), J = ((h = (u = (c = m == null ? void 0 : m.candidates) == null ? void 0 : c[0]) == null ? void 0 : u.content) == null ? void 0 : h.parts) || [];
      for (const y of J)
        y.inlineData && (a = y.inlineData.data, s = y.inlineData.mimeType || "image/png"), y.text && typeof y.text == "string" && y.text.length > 10 && (r = y.text);
      console.log("[sw] Proxy Gemini response:", { hasImage: !!a, hasText: !!r });
    } else {
      const m = await l.json().catch(() => ({ error: `HTTP ${l.status}` }));
      console.error("[sw] Proxy Gemini error", m.error || l.status);
    }
  } catch (l) {
    console.log("[sw] Proxy Gemini error", l);
  }
  if (!r)
    try {
      console.log("[sw] falling back to Claude via proxy for post text");
      const l = await fetch(`${normalizeServiceBase(g())}/claude`, {
        method: "POST",
        headers: f(),
        body: JSON.stringify({
          model: "claude-haiku-4-5-20251001",
          max_tokens: 200,
          system: "You write professional LinkedIn posts. Be concise and insightful. No hashtags unless they flow naturally." + (n ? ` Follow this guidance: ${n}` : ""),
          messages: [{ role: "user", content: `Write a short, professional LinkedIn post about ${e || "industry trends"}. 2-3 sentences, under 500 chars. Natural tone.` }]
        })
      });
      if (l.ok) {
        const m = await l.json();
        r = ((O = (L = (k = m == null ? void 0 : m.content) == null ? void 0 : k[0]) == null ? void 0 : L.text) == null ? void 0 : O.trim()) || "", console.log("[sw] Proxy Claude post text generated, length:", (r || "").length);
      } else {
        const m = await l.json().catch(() => ({ error: `HTTP ${l.status}` }));
        console.error("[sw] Proxy Claude error", m.error || l.status);
      }
    } catch (l) {
      console.log("[sw] Proxy Claude post text error", l);
    }
  return { imageBase64: a, imageMimeType: s, text: r };
}
async function pe(e, t) {
  switch (e) {
    case "getPipeline":
      return R();
    case "getDailyStats":
      return B();
    case "getWeeklyStats":
      return Z();
    case "getUnreplied":
      return X();
    case "getLeadsByStatus":
      return V(t.status);
    default:
      return null;
  }
}
chrome.alarms.create("midnight", { when: fe(), periodInMinutes: 1440 });
chrome.alarms.create("sync-retry", { periodInMinutes: 1 });
function fe() {
  const e = /* @__PURE__ */ new Date();
  return new Date(e.getFullYear(), e.getMonth(), e.getDate() + 1).getTime();
}
const v = "autoComment";
chrome.storage.onChanged.addListener((e) => {
  (e.autoCommentDaily || e.commentScheduleHour) && U(), (e.autoPostDaily || e.postScheduleHour) && j(), (e.autoMessageDaily || e.messageScheduleHour) && G();
});
async function U() {
  const { autoCommentDaily: e, commentScheduleHour: t } = await chrome.storage.sync.get({
    autoCommentDaily: !1,
    commentScheduleHour: "9"
  }), n = await chrome.alarms.get(v);
  if (e) {
    const o = Number(t) || 9, a = /* @__PURE__ */ new Date(), s = new Date(a.getFullYear(), a.getMonth(), a.getDate(), o, 7, 0);
    s.getTime() <= a.getTime() && s.setDate(s.getDate() + 1), (!n || n.scheduledTime !== s.getTime()) && (chrome.alarms.create(v, {
      when: s.getTime(),
      periodInMinutes: 1440
    }), console.log("[sw] auto-comment alarm set for", s.toLocaleString()));
  } else
    n && (chrome.alarms.clear(v), console.log("[sw] auto-comment alarm cleared"));
}
const S = "autoPost";
async function j() {
  const { autoPostDaily: e, postScheduleHour: t } = await chrome.storage.sync.get({
    autoPostDaily: !1,
    postScheduleHour: "10"
  }), n = await chrome.alarms.get(S);
  if (e) {
    const o = Number(t) || 10, a = /* @__PURE__ */ new Date(), s = new Date(a.getFullYear(), a.getMonth(), a.getDate(), o, 13, 0);
    s.getTime() <= a.getTime() && s.setDate(s.getDate() + 1), (!n || n.scheduledTime !== s.getTime()) && (chrome.alarms.create(S, {
      when: s.getTime(),
      periodInMinutes: 1440
    }), console.log("[sw] auto-post alarm set for", s.toLocaleString()));
  } else
    n && (chrome.alarms.clear(S), console.log("[sw] auto-post alarm cleared"));
}
chrome.alarms.onAlarm.addListener(async (e) => {
  if (e.name === "sync-retry") {
    await flushSyncQueue();
    return;
  }
  if (e.name === "midnight" && (chrome.storage.local.remove("dailyConnectionCount"), chrome.storage.local.remove("dailyCommentCount"), chrome.storage.local.remove("dailyPostCount"), chrome.storage.local.remove("dailyMessageCount"), i = { ...i, count: 0, commentCount: 0, postCount: 0, messageCount: 0 }, console.log("[sw] midnight reset — daily counts cleared")), e.name === v) {
    console.log("[sw] auto-comment alarm fired");
    const { commentSearchKeyword: t } = await chrome.storage.sync.get({ commentSearchKeyword: "" }), n = t || "", o = n ? `https://www.linkedin.com/search/results/content/?keywords=${encodeURIComponent(n)}` : "https://www.linkedin.com/search/results/content/";
    chrome.tabs.create({ url: o }, (a) => {
      if (a != null && a.id) {
        const s = a.id;
        setTimeout(() => {
          chrome.tabs.sendMessage(s, { action: "start" }).catch(() => {
            console.log("[sw] auto-comment: tab not ready yet");
          }), i = { ...i, isRunning: !0 };
        }, 5e3);
      }
    });
  }
  e.name === S && (console.log("[sw] auto-post alarm fired"), chrome.tabs.create({ url: "https://www.linkedin.com/feed/" }, (t) => {
    if (t != null && t.id) {
      const n = t.id;
      setTimeout(() => {
        chrome.tabs.sendMessage(n, { action: "start" }).catch(() => {
          console.log("[sw] auto-post: tab not ready yet");
        }), i = { ...i, isRunning: !0 };
      }, 5e3);
    }
  })), e.name === P && (console.log("[sw] auto-message alarm fired"), chrome.tabs.create({ url: "https://www.linkedin.com/messaging/" }, (t) => {
    if (t != null && t.id) {
      const n = t.id;
      setTimeout(() => {
        chrome.tabs.sendMessage(n, { action: "start" }).catch(() => {
          console.log("[sw] auto-message: tab not ready yet");
        }), i = { ...i, isRunning: !0 };
      }, 5e3);
    }
  }));
});
const P = "autoMessage";
async function G() {
  const { autoMessageDaily: e, messageScheduleHour: t } = await chrome.storage.sync.get({
    autoMessageDaily: !1,
    messageScheduleHour: "9"
  }), n = await chrome.alarms.get(P);
  if (e) {
    const o = Number(t) || 9, a = /* @__PURE__ */ new Date(), s = new Date(a.getFullYear(), a.getMonth(), a.getDate(), o, 23, 0);
    s.getTime() <= a.getTime() && s.setDate(s.getDate() + 1), (!n || n.scheduledTime !== s.getTime()) && (chrome.alarms.create(P, {
      when: s.getTime(),
      periodInMinutes: 1440
    }), console.log("[sw] auto-message alarm set for", s.toLocaleString()));
  } else
    n && (chrome.alarms.clear(P), console.log("[sw] auto-message alarm cleared"));
}
U();
j();
G();
async function we(e, t, n) {
  if (!e) {
    console.log("[sw] cdpClick: no tabId");
    return;
  }
  try {
    await chrome.debugger.attach({ tabId: e }, "1.3"), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchMouseEvent", {
      type: "mouseMoved",
      x: t,
      y: n,
      pointerType: "mouse"
    }), await new Promise((o) => setTimeout(o, 50)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      x: t,
      y: n,
      button: "left",
      clickCount: 1,
      pointerType: "mouse"
    }), await new Promise((o) => setTimeout(o, 80 + Math.random() * 120)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x: t,
      y: n,
      button: "left",
      clickCount: 1,
      pointerType: "mouse"
    }), console.log(`[sw] CDP click dispatched at (${Math.round(t)}, ${Math.round(n)})`);
  } catch (o) {
    console.log("[sw] CDP click failed:", o.message);
  } finally {
    chrome.debugger.detach({ tabId: e }).catch(() => {
    });
  }
}
async function Ce(e) {
  if (!e) {
    console.log("[sw] cdpPaste: no tabId");
    return;
  }
  try {
    await chrome.debugger.attach({ tabId: e }, "1.3"), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "Control",
      code: "ControlLeft",
      keyCode: 17,
      windowsVirtualKeyCode: 17
    }), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "v",
      code: "KeyV",
      keyCode: 86,
      modifiers: 2,
      windowsVirtualKeyCode: 86
    }), await new Promise((t) => setTimeout(t, 30 + Math.random() * 40)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "v",
      code: "KeyV",
      keyCode: 86,
      modifiers: 2,
      windowsVirtualKeyCode: 86
    }), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "Control",
      code: "ControlLeft",
      keyCode: 17,
      windowsVirtualKeyCode: 17
    }), console.log("[sw] CDP paste dispatched");
  } catch (t) {
    console.log("[sw] CDP paste failed:", t.message);
  } finally {
    chrome.debugger.detach({ tabId: e }).catch(() => {
    });
  }
}
async function Te(e) {
  if (!e) {
    console.log("[sw] cdpEscape: no tabId");
    return;
  }
  try {
    await chrome.debugger.attach({ tabId: e }, "1.3"), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: "Escape",
      code: "Escape",
      keyCode: 27,
      windowsVirtualKeyCode: 27,
      nativeVirtualKeyCode: 27
    }), await new Promise((t) => setTimeout(t, 50)), await chrome.debugger.sendCommand({ tabId: e }, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: "Escape",
      code: "Escape",
      keyCode: 27,
      windowsVirtualKeyCode: 27,
      nativeVirtualKeyCode: 27
    }), console.log("[sw] CDP Escape dispatched");
  } catch (t) {
    console.log("[sw] CDP Escape failed:", t.message);
  } finally {
    chrome.debugger.detach({ tabId: e }).catch(() => {
    });
  }
}
