function d(e) {
  let n = [];
  return [(t) => {
    let o = e;
    e = t;
    let r = n;
    for (; r[2] && (r = r[2], r[0](t, o), t === e); ) ;
  }, (t) => {
    let o = n;
    for (; o[2]; ) o = o[2];
    return o = o[2] = [t, o], () => {
      o && (o[1][2] = o[2], o = 0);
    };
  }, () => e];
}
const wn = d("25"), [Ot, , Ke] = wn, Mn = d(0), [We, Cn, je] = Mn;
function de() {
  const e = /* @__PURE__ */ new Date();
  return `${e.getFullYear()}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`;
}
var F = /* @__PURE__ */ ((e) => (e[e.Unidentified = 0] = "Unidentified", e[e.SearchPeople = 1] = "SearchPeople", e[e.MyNetwork = 2] = "MyNetwork", e[e.PostSearch = 3] = "PostSearch", e[e.PostFeed = 4] = "PostFeed", e[e.Messaging = 5] = "Messaging", e[e.Connections = 6] = "Connections", e))(F || {}), Z = /* @__PURE__ */ ((e) => (e.SearchPeoplePage = "https://www.linkedin.com/search/results/people/", e.MyNetworkPage = "https://www.linkedin.com/mynetwork/", e.PostSearchPage = "https://www.linkedin.com/search/results/content/", e.FeedPage = "https://www.linkedin.com/feed/", e.MessagingPage = "https://www.linkedin.com/messaging/", e.ConnectionsPage = "https://www.linkedin.com/mynetwork/invite-connect/connections/", e.PatternOfSearchPage = "linkedin.com/search/results/people", e.PatternOfMyNetworkPage = "linkedin.com/mynetwork", e.PatternOfConnectionsPage = "linkedin.com/mynetwork/invite-connect/connections", e.PatternOfPostSearchPage = "linkedin.com/search/results/content", e.PatternOfFeedPage = "linkedin.com/feed", e.PatternOfMessagingPage = "linkedin.com/messaging", e))(Z || {});
const Pn = d(
  "normal"
  /* Normal */
), [Ht, , Sn] = Pn, xn = d(""), [It, , vn] = xn, kn = d("https://confido-key.lovable.app/api/public"), [_n, , Tn] = kn, An = d(""), [En, , Xs] = An, Dn = d("0"), [Vt, , Nn] = Dn, Fn = d("10"), [$t, , Ye] = Fn, Bn = d(0), [Xe, Us, Ue] = Bn, Rn = d([""]), [Lt, , Kt] = Rn, qn = d(""), [Wt, , zs] = qn, On = d(!1), [jt, , Gs] = On, Hn = d("9"), [Yt, , Qs] = Hn, In = d("3"), [Xt, , ze] = In, Vn = d(0), [Ge, Zs, Qe] = Vn, $n = d(!1), [Ut, , Js] = $n, Ln = d("10"), [zt, , er] = Ln, Kn = d(""), [Gt, , Wn] = Kn, jn = d("30"), [Qt, , mt] = jn, Yn = d("120"), [Zt, , dt] = Yn, Xn = d(""), [Jt, , Un] = Xn, zn = d([""]), [en, , Gn] = zn, Qn = d("15"), [tn, , Ze] = Qn, Zn = d(0), [Je, tr, et] = Zn, Jn = d([""]), [nn, , eo] = Jn, to = d(!1), [on, , nr] = to, no = d("9"), [sn, , or] = no, oo = d(!1), [rn, , so] = oo, ro = d([""]), [an, , io] = ro, ao = d("10"), [cn, , ft] = ao, co = d(0), [tt, sr, qe] = co;
function E() {
  const e = Sn();
  return e === "slow" ? 5 : e === "fast" ? 0.5 : 1;
}
function p(e) {
  return new Promise((n) => setTimeout(n, e));
}
async function lo() {
  const {
    maximumAutoConnectionsPerDay: e,
    maximumAutoConnectionsPerSession: n,
    speedPreset: t,
    connectionNote: o,
    sessionDurationMinutes: r,
    maximumAutoCommentsPerDay: a,
    commentPool: i,
    commentSearchKeyword: c,
    autoCommentDaily: u,
    commentScheduleHour: g,
    maximumAutoPostsPerDay: s,
    postTopic: m,
    postIntervalMinutesMin: f,
    postIntervalMinutesMax: h,
    postImagePrompt: D,
    postTextPool: A,
    autoPostDaily: w,
    postScheduleHour: v,
    maximumAutoMessagesPerDay: N,
    messageReplyPool: C,
    autoMessageDaily: V,
    messageScheduleHour: te,
    replyToConnectionsOnly: K,
    messageFirstPool: R,
    maximumAutoFirstMessagesPerDay: xe,
    apiBase: ve,
    apiKey: ke
  } = await new Promise(
    (H) => {
      chrome.storage.sync.get(
        { maximumAutoConnectionsPerDay: "", maximumAutoConnectionsPerSession: "", speedPreset: "normal", connectionNote: "", sessionDurationMinutes: "", maximumAutoCommentsPerDay: "", commentPool: [""], commentSearchKeyword: "", autoCommentDaily: !1, commentScheduleHour: "9", maximumAutoPostsPerDay: "", postTopic: "", postIntervalMinutesMin: "", postIntervalMinutesMax: "", postImagePrompt: "", postTextPool: [""], autoPostDaily: !1, postScheduleHour: "10", maximumAutoMessagesPerDay: "", messageReplyPool: [""], autoMessageDaily: !1, messageScheduleHour: "9", replyToConnectionsOnly: !1, messageFirstPool: [""], maximumAutoFirstMessagesPerDay: "", apiBase: "", apiKey: "" },
        (I) => H(I)
      );
    }
  ), Q = e || n || Ke();
  Ot(Q), Ht(
    t || "normal"
    /* Normal */
  ), It(o || ""), Vt(r || "0"), $t(a || Ye()), Lt(i || [""]), Wt(c || ""), jt(u || !1), Yt(g || "9"), Xt(s || ze()), Gt(m || ""), Qt(f || mt()), Zt(h || dt()), Jt(D || ""), en(A || [""]), Ut(w || !1), zt(v || "10"), tn(N || Ze()), nn(C || [""]), on(V || !1), sn(te || "9"), rn(K === !0), an(R || [""]), cn(xe || ft()), _n(ve || Tn()), En(ke || "");
  const W = de(), { dailyConnectionCount: U } = await new Promise(
    (H) => {
      chrome.storage.local.get("dailyConnectionCount", (I) => H(I));
    }
  );
  (U == null ? void 0 : U.date) === W ? We(U.count) : We(0);
  const { dailyCommentCount: ge } = await new Promise(
    (H) => {
      chrome.storage.local.get("dailyCommentCount", (I) => H(I));
    }
  );
  (ge == null ? void 0 : ge.date) === W ? Xe(ge.count) : Xe(0);
  const { dailyPostCount: _e } = await new Promise(
    (H) => {
      chrome.storage.local.get("dailyPostCount", (I) => H(I));
    }
  );
  (_e == null ? void 0 : _e.date) === W ? Ge(_e.count) : Ge(0);
  const { dailyMessageCount: Te } = await new Promise(
    (H) => {
      chrome.storage.local.get("dailyMessageCount", (I) => H(I));
    }
  );
  (Te == null ? void 0 : Te.date) === W ? Je(Te.count) : Je(0);
  const { dailyFirstMessageCount: Ae } = await new Promise(
    (H) => {
      chrome.storage.local.get("dailyFirstMessageCount", (I) => H(I));
    }
  );
  (Ae == null ? void 0 : Ae.date) === W ? tt(Ae.count) : tt(0);
}
async function uo(e) {
  await chrome.storage.local.set({ dailyConnectionCount: { date: de(), count: e } });
}
async function mo(e) {
  await chrome.storage.local.set({ dailyCommentCount: { date: de(), count: e } });
}
async function fo(e) {
  await chrome.storage.local.set({ dailyPostCount: { date: de(), count: e } });
}
async function go(e) {
  await chrome.storage.local.set({ dailyMessageCount: { date: de(), count: e } });
}
async function po(e) {
  await chrome.storage.local.set({ dailyFirstMessageCount: { date: de(), count: e } });
}
const fe = 5;
let be = !1;
const [ht, ho] = d(), [bo, yo] = d(), [wo, Mo] = d(), [Co, Po] = d(), [$, So] = d(), [xo, vo] = d(), [ko, _o] = d(), [ne, , oe] = d(F.Unidentified), [bt, To, y] = d(!1);
let J = !1;
let connectionButton = null;
const le = /* @__PURE__ */ new Set(), ue = /* @__PURE__ */ new Set();
function yt() {
  chrome.storage.local.set({
    commentedAuthors: [...le].slice(-500),
    commentedPosts: [...ue].slice(-500)
  });
}
function gt(e) {
  return e.replace(/\s+/g, " ").replace(/^View\s+/i, "").replace(/[’']s?\s*profile\b.*$/i, "").replace(/[’']s$/i, "").replace(/[,\s]+/g, " ").trim();
}
function z(e) {
  return gt(e).toLowerCase().substring(0, 60);
}
let nt = null;
function wt(e) {
  var o;
  if (e.disabled || ((o = e.textContent) == null ? void 0 : o.trim()) !== "Comment") return !1;
  const n = ws(e);
  if (!n.author) return !1;
  const t = he(n.text);
  return t && ue.has(t) || le.has(z(n.author)) || Ao(e) ? !1 : (nt = n, !0);
}
function Ao(e) {
  let n = e.parentElement;
  for (let t = 0; t < 15 && !(!n || n === document.body); t++) {
    const o = n.querySelectorAll('a[href*="/in/"]');
    if (o.length > 0) {
      for (const r of o) {
        const a = (r.textContent || "").replace(/\s+/g, " ").trim();
        if (a.length >= 2 && /(^|\s)You(?=\s|[A-Z]|$)/.test(a)) return !0;
      }
      return !1;
    }
    n = n.parentElement;
  }
  return !1;
}
const [Mt, Eo] = d(), [Do, No] = d(), [Fo, Bo] = d(), [Ro, qo] = d();
let L = !1;
const pe = /* @__PURE__ */ new Set();
function Oo() {
  chrome.storage.local.set({
    postFingerprints: [...pe].slice(-200)
  });
}
function he(e) {
  return e.toLowerCase().trim().replace(/\s+/g, " ").substring(0, 100);
}
const [Ho, Io] = d(), [Vo, $o] = d(), [Lo, Ko] = d(), [Wo, jo] = d();
let T = !1;
const Oe = /* @__PURE__ */ new Set(), ot = /* @__PURE__ */ new Set(), Ee = /* @__PURE__ */ new Set();
let st = "", rt = "";
function Ct() {
  chrome.storage.local.set({
    conversations: {
      replied: [...Oe].slice(-500),
      skipped: [...ot].slice(-500)
    }
  });
}
function pt(e) {
  var n, t;
  return ((t = (n = e.querySelector(".msg-conversation-listitem__participant-names")) == null ? void 0 : n.textContent) == null ? void 0 : t.replace(/\s+/g, " ").trim()) || "";
}
function Yo() {
  const e = document.querySelector(".msg-conversation-listitem__link--active");
  if (!e) return "";
  const n = e.closest("li.msg-conversation-listitem");
  return n ? pt(n) : "";
}
function $e() {
  var t, o, r, a, i;
  const e = [], n = document.querySelectorAll(".msg-s-event-listitem--other");
  for (const c of n) {
    const u = c.getAttribute("data-event-urn") || "", g = c.querySelector(".msg-s-message-group__name"), s = c.querySelector(".msg-s-event-listitem__profile-picture img"), m = ((t = g == null ? void 0 : g.textContent) == null ? void 0 : t.replace(/\s+/g, " ").trim()) || ((o = s == null ? void 0 : s.getAttribute("alt")) == null ? void 0 : o.trim()) || ((r = s == null ? void 0 : s.getAttribute("title")) == null ? void 0 : r.trim()) || "", f = ((i = (a = c.querySelector(".msg-s-event-listitem__body")) == null ? void 0 : a.textContent) == null ? void 0 : i.replace(/\s+/g, " ").trim()) || "";
    f.length >= 2 && e.push({ urn: u, sender: m, text: f.substring(0, 500) });
  }
  return l("extractInboundMessages", { count: e.length }), e;
}
function Xo(e, n) {
  return `${e}|${n}`.toLowerCase().replace(/\s+/g, " ").trim().substring(0, 120);
}
const [Uo, zo] = d(), [Go, Qo] = d(), [Zo, Jo] = d(), [es, ts] = d(), [ns, os] = d();
function l(e, n) {
  chrome.runtime.sendMessage({ action: "debug", msg: e, data: n }).catch(() => {
  });
}
const it = "dm:trace", Pt = 200;
let se = [], St = !1, De = null;
async function ss() {
  if (!St) {
    try {
      se = (await chrome.storage.local.get(it))[it] || [];
    } catch {
    }
    St = !0;
  }
}
function S(e, n, t, o = {}) {
  se.push({ ts: Date.now(), step: e, outcome: n, reason: t, evidence: o }), se.length > Pt && se.splice(0, se.length - Pt), l(`[dm:${e}:${n}] ${t}`, o), De && clearTimeout(De), De = setTimeout(() => {
    De = null, chrome.storage.local.set({ [it]: se.slice(-200) }).catch(() => {
    });
  }, 250);
}
const at = "connect:trace", xt = 200;
let re = [], vt = !1, Ne = null;
async function rs() {
  if (!vt) {
    try {
      re = (await chrome.storage.local.get(at))[at] || [];
    } catch {
    }
    vt = !0;
  }
}
function q(e, n, t, o = {}) {
  re.push({ ts: Date.now(), step: e, outcome: n, reason: t, evidence: o }), re.length > xt && re.splice(0, re.length - xt), l(`[connect:${e}:${n}] ${t}`, o), Ne && clearTimeout(Ne), Ne = setTimeout(() => {
    Ne = null, chrome.storage.local.set({ [at]: re.slice(-200) }).catch(() => {
    });
  }, 250);
}
const ct = "firstmsg:trace", kt = 200;
let ie = [], _t = !1, Fe = null;
async function is() {
  if (!_t) {
    try {
      ie = (await chrome.storage.local.get(ct))[ct] || [];
    } catch {
    }
    _t = !0;
  }
}
function k(e, n, t, o = {}) {
  ie.push({ ts: Date.now(), step: e, outcome: n, reason: t, evidence: o }), ie.length > kt && ie.splice(0, ie.length - kt), l(`[firstmsg:${e}:${n}] ${t}`, o), Fe && clearTimeout(Fe), Fe = setTimeout(() => {
    Fe = null, chrome.storage.local.set({ [ct]: ie.slice(-200) }).catch(() => {
    });
  }, 250);
}
const lt = "comment:trace", Tt = 200;
let ae = [], At = !1, Be = null;
async function as() {
  if (!At) {
    try {
      ae = (await chrome.storage.local.get(lt))[lt] || [];
    } catch {
    }
    At = !0;
  }
}
function P(e, n, t, o = {}) {
  ae.push({ ts: Date.now(), step: e, outcome: n, reason: t, evidence: o }), ae.length > Tt && ae.splice(0, ae.length - Tt), l(`[comment:${e}:${n}] ${t}`, o), Be && clearTimeout(Be), Be = setTimeout(() => {
    Be = null, chrome.storage.local.set({ [lt]: ae.slice(-200) }).catch(() => {
    });
  }, 250);
}
function ye(e) {
  const n = {};
  for (const t of e) {
    let o;
    try {
      o = [...document.querySelectorAll(t.selector)].filter((r) => t.match ? t.match(r) : !0);
    } catch {
      o = [];
    }
    n[t.name] = {
      found: o.length,
      sample: o.slice(0, 3).map((r) => (r.outerHTML || r.tagName).replace(/\s+/g, " ").substring(0, 160))
    };
  }
  return n;
}
const we = [
  {
    name: "message_link",
    selector: "a",
    match: (e) => (e.textContent || "").trim() === "Message" && (e.getAttribute("aria-label") || "").startsWith("Send a message to ")
  },
  { name: "composer_editor", selector: 'div.msg-form__contenteditable[contenteditable="true"][role="textbox"]' },
  { name: "composer_form", selector: "form.msg-form" },
  { name: "send_button", selector: "button.msg-form__send-button" }
];
function cs() {
  return {
    page: oe(),
    href: window.location.href,
    firstMessage: ye(we)
  };
}
function ln() {
  for (const e of document.querySelectorAll("*")) {
    const n = Object.keys(e).find(
      (t) => t.startsWith("__reactFiber$") || t.startsWith("__reactInternalInstance$")
    );
    if (n) {
      let t = e[n];
      for (; t.return; ) t = t.return;
      return t;
    }
  }
  return null;
}
function me(e) {
  const n = ln();
  if (n) {
    let t = function(a) {
      return !a || o.has(a) ? null : (o.add(a), a.stateNode instanceof HTMLButtonElement && e(a.stateNode) ? a.stateNode : t(a.child) || t(a.sibling));
    };
    const o = /* @__PURE__ */ new Set(), r = t(n);
    if (r) return r;
  }
  for (const t of document.querySelectorAll("button"))
    if (e(t)) return t;
  return null;
}
function G(e) {
  try {
    e.scrollIntoView({ block: "center" }), e.click();
  } catch (n) {
    l("clickElement error", { message: n == null ? void 0 : n.message });
  }
}
function ls(e, n) {
  const t = document.createElement("div");
  t.id = "__autoconnect_note_preview";
  const o = document.getElementById(t.id);
  o && o.remove(), t.style.cssText = "position:fixed;bottom:24px;right:24px;z-index:99999;max-width:360px;padding:14px 18px;background:#1a202c;color:#e2e8f0;border-radius:10px;box-shadow:0 8px 30px rgba(0,0,0,0.4);font:13px/1.5 -apple-system,BlinkMacSystemFont,sans-serif;transition:opacity 0.3s;", t.innerHTML = `<div style="font-weight:600;margin-bottom:6px;color:#68d391;">AI Note for ${n || "this person"}</div><div>${e}</div>`, document.body.appendChild(t), setTimeout(() => {
    t.style.opacity = "0", setTimeout(() => t.remove(), 300);
  }, 6e3);
}
function He() {
  const e = E(), n = (2e3 + Math.floor(-Math.log(1 - Math.random()) * 3e3)) * e;
  return Math.random() < 0.1 ? Math.min(n + (6e3 + Math.floor(Math.random() * 1e4)) * e, 3e4 * e) : Math.min(n, 18e3 * e);
}
async function Se() {
  const e = E(), n = Math.random();
  if (n < 0.4) {
    const r = window.innerHeight * (0.7 + Math.random() * 0.4), a = Math.round((4 + Math.floor(Math.random() * 8)) / e);
    for (let i = 0; i < a; i++)
      window.scrollBy({ top: r / a, behavior: "smooth" }), await p((25 + Math.random() * 70) * e);
    Math.random() < 0.3 && (await p((150 + Math.random() * 250) * e), window.scrollBy({ top: -(30 + Math.random() * 80), behavior: "smooth" }));
    return;
  }
  if (n < 0.65) {
    const r = document.body.scrollHeight - window.innerHeight, i = Math.min(r, window.scrollY + window.innerHeight * (0.2 + Math.random() * 0.5)) - window.scrollY;
    if (i <= 0) return;
    const c = Math.round((3 + Math.floor(Math.random() * 6)) / e);
    for (let u = 0; u < c; u++)
      window.scrollBy({ top: i / c, behavior: "smooth" }), await p((20 + Math.random() * 60) * e);
    return;
  }
  const t = document.body.scrollHeight - window.scrollY;
  if (t <= 0) return;
  const o = Math.round((5 + Math.floor(Math.random() * 10)) / e);
  for (let r = 0; r < o; r++)
    window.scrollBy({ top: t / o, behavior: "smooth" }), await p((30 + Math.random() * 80) * e);
}
async function ee(e) {
  const n = E();
  e.scrollIntoView({ block: "center", behavior: "smooth" }), await p((150 + Math.random() * 200) * n), e.dispatchEvent(new MouseEvent("mouseenter", { bubbles: !0 })), e.dispatchEvent(new MouseEvent("mouseover", { bubbles: !0 })), await p((200 + Math.random() * 600) * n);
}
let B = "";
function us(e) {
  var i, c, u;
  let n = e.parentElement;
  for (let g = 0; g < 10 && !(!n || n === document.body || n.tagName === "LI" || n.querySelector('a[href*="/in/"]')); g++)
    n = n.parentElement;
  const t = n.querySelector('a[href*="/in/"]');
  let o = "";
  if (t && (o = (t.getAttribute("aria-label") || "").replace(/^(View|查看)\s+/, "").replace(/[’']s\s+profile\s*$/i, "").replace(/\s*profile\s*$/i, "").trim(), !o || o.length < 2 || o.length > 80)) {
    const s = document.createTreeWalker(t, NodeFilter.SHOW_TEXT);
    for (; s.nextNode(); ) {
      const m = ((i = s.currentNode.textContent) == null ? void 0 : i.trim()) || "";
      if (m.length >= 2 && m.length <= 60 && !m.includes("/") && !m.startsWith("http")) {
        o = m;
        break;
      }
    }
    o || (o = ((c = t.textContent) == null ? void 0 : c.trim().replace(/\s+/g, " ").substring(0, 60)) || "");
  }
  let r = "";
  const a = document.createTreeWalker(n, NodeFilter.SHOW_TEXT);
  for (; a.nextNode(); ) {
    const g = ((u = a.currentNode.textContent) == null ? void 0 : u.trim().replace(/\s+/g, " ")) || "", s = a.currentNode.parentElement;
    if (s && g !== o && !(g.length < 15 || g.length > 200) && !(g === "Connect" || g === "Message" || g === "Follow") && !s.closest("button") && s.tagName !== "A" && !s.closest('a[href*="/in/"]')) {
      r = g;
      break;
    }
  }
  return l("extractProfile", { name: o, headline: r }), { name: o, headline: r };
}
async function ms(e) {
  try {
    B = await chrome.runtime.sendMessage({ action: "generateNote", profile: e }), l("AI note generated", { len: B.length }), B && chrome.runtime.sendMessage({ action: "noteGenerated", name: e.name, note: B }).catch(() => {
    });
  } catch {
    B = "";
  }
}
async function ds() {
  var n;
  if (be) return;
  be = !0;
  let e = 0;
  for (l("findNextAvailableConnectButton started"); e < fe && y(); ) {
    await Se(), await p((800 + Math.random() * 2200) * E());
    const t = me(
      (o) => {
        var r;
        return !o.disabled && !o.dataset.autoconnected && ((r = o.textContent) == null ? void 0 : r.trim()) === "Connect";
      }
    );
    if (t) {
      if (Math.random() < 0.12) {
        t.dataset.autoconnected = "true", q("discover", "skip", "random_skip", { via: "findButton" });
        continue;
      }
      q("discover", "ok", "button_found", { via: "findButton" }), await ee(t), ht(t);
      return;
    }
    e++;
  }
  l("fiber walk exhausted, trying DOM fallback");
  for (const t of document.querySelectorAll("button"))
    if (!t.disabled && !t.dataset.autoconnected && ((n = t.textContent) == null ? void 0 : n.trim()) === "Connect") {
      if (Math.random() < 0.12) {
        t.dataset.autoconnected = "true", q("discover", "skip", "random_skip", { via: "fallback" });
        continue;
      }
      q("discover", "ok", "button_found", { via: "fallback" }), await ee(t), ht(t);
      return;
    }
  q("discover", "info", "no_button", { attempts: e }), bo(), be = !1;
}
function Et() {
  chrome.storage.local.set({ messagedConns: [...Me].slice(-500) }).catch(() => {
  });
}
function fs(e) {
  var n;
  try {
    const t = new URL(e.href), o = t.searchParams.get("recipient");
    if (o) return o;
    const r = t.searchParams.get("profileUrn");
    if (r) return r;
  } catch {
  }
  return ((n = e.href) == null ? void 0 : n.split("?")[0]) || un(e);
}
function un(e) {
  const t = (e.getAttribute("aria-label") || "").match(/^Send a message to (.+)$/);
  return t ? t[1].trim() : "";
}
function gs() {
  const e = io().filter((n) => n.trim());
  return e.length ? e[Math.floor(Math.random() * e.length)] : "Hey, wanted to reach out — hope you're doing well!";
}
async function ps() {
  var n, t;
  if (j || T) return;
  j = !0;
  let e = 0;
  for (l("searchForNextMessageButton started"); e < fe && y(); ) {
    await Se(), await p((800 + Math.random() * 2200) * E());
    for (const o of document.querySelectorAll("a")) {
      if ((o.textContent || "").trim() !== "Message" || !(o.getAttribute("aria-label") || "").startsWith("Send a message to ")) continue;
      const i = un(o);
      if (!i) continue;
      const c = fs(o);
      if (Me.has(c)) {
        k("discover", "skip", "already_messaged", { name: i, fingerprint: c });
        continue;
      }
      if (ut.has(c)) {
        k("discover", "skip", "previously_skipped", { name: i, fingerprint: c });
        continue;
      }
      if (Math.random() < 0.12) {
        ut.add(c), k("discover", "skip", "random_skip", { name: i, fingerprint: c });
        continue;
      }
      k("discover", "ok", "message_link_found", { name: i, fingerprint: c }), ce = i, M(), await ee(o), o.scrollIntoView({ block: "center", behavior: "instant" }), await p(400);
      const u = o.getBoundingClientRect(), g = Math.round(u.left + u.width / 2), s = Math.round(u.top + u.height / 2);
      k("open", "info", "cdp_click", {
        name: i,
        x: g,
        y: s,
        innerWidth: window.innerWidth,
        rect: { left: Math.round(u.left), top: Math.round(u.top), w: Math.round(u.width), h: Math.round(u.height) }
      }), chrome.runtime.sendMessage({ action: "cdpClick", x: g, y: s });
      const m = await $s(9e3);
      if (!y()) {
        j = !1;
        return;
      }
      if (!m) {
        k("open", "fail", "composer_missing", { name: i, dom: ye(we) }), await Re(), ce = "", M(), j = !1, y() && _();
        return;
      }
      k("open", "ok", "composer_ready", {
        name: i,
        editor: Ce(m.editor),
        sendBtnDisabled: m.sendButton.disabled
      }), gn(), await p(400);
      const f = Ws();
      if (f.hasThread) {
        const v = f.latestOurs ? "latest_is_ours" : f.hasInbound ? "already_replied" : "existing_thread";
        k("open", "skip", v, { name: i, ...f }), Me.add(c), Et(), await Re(), ce = "", M(), j = !1, y() && _();
        return;
      }
      let h = await Promise.race([
        chrome.runtime.sendMessage({ action: "generateFirstMessage", profile: { name: i } }).catch(() => ""),
        p(4e3 * E()).then(() => "")
      ]);
      if (h || (h = gs()), !h) {
        k("fill", "skip", "no_text", { name: i }), ce = "", M(), await Re(), j = !1;
        return;
      }
      let D = !1;
      const A = (n = O()) == null ? void 0 : n.editor, w = A ? await pn(h, A) : !1;
      if (k("fill", w ? "ok" : "fail", "composer_filled", { name: i }), w) {
        await p(300);
        for (let v = 0; v < 5; v++) {
          if (hn((t = O()) == null ? void 0 : t.sendButton)) {
            await p(1500);
            const N = bn(), C = yn(h);
            N || C ? (k("send", "ok", "send_verified", { name: i, editorEmpty: N, textInThread: C }), D = !0) : k("send", "fail", "send_unverified", { name: i, editorEmpty: N, textInThread: C, dom: ye(we) });
            break;
          }
          await p(500);
        }
      }
      if (D) {
        Me.add(c), Et();
        const v = qe() + 1;
        tt(v), po(v), k("record", "ok", "recorded_sent", { name: i, fingerprint: c }), chrome.runtime.sendMessage({
          action: "reportActivity",
          data: { connections: 0, comments: 0, posts: 0, messagesSent: 1, messagesReceived: 0 }
        }).catch(() => {
        }), chrome.runtime.sendMessage({
          action: "reportFirstMessaged",
          data: { name: i, messageText: h }
        }).catch(() => {
        });
      } else
        k("record", "skip", "recorded_skipped", { name: i, fingerprint: c });
      await Re(), ce = "", M(), y() && qe() >= Number(ft()) && (k("record", "info", "daily_cap_reached", { count: qe() }), $()), await p(He()), j = !1, y() && _();
      return;
    }
    e++;
  }
  k("discover", "info", "no_message_links", { attempts: e, dom: ye(we) }), j = !1;
}
function hs(e) {
  const n = Pe(e);
  return n.find((t) => {
    const o = t.getBoundingClientRect();
    return o.width > 0 && o.height > 0;
  }) || n[0] || null;
}
function Pe(e) {
  const n = [], t = (o) => {
    o.querySelectorAll(e).forEach((r) => n.push(r)), o.querySelectorAll("*").forEach((r) => {
      r.shadowRoot && t(r.shadowRoot);
    });
  };
  return t(document), n;
}
function Dt(e) {
  return new Promise((n) => {
    const t = Date.now(), o = setInterval(() => {
      O() ? Date.now() - t >= e && (clearInterval(o), n(!1)) : (clearInterval(o), n(!0));
    }, 200);
  });
}
async function Re() {
  var o;
  const e = document.getElementById("interop-outlet"), n = e == null ? void 0 : e.shadowRoot;
  let t = null;
  if (n) {
    const r = n.querySelector('svg[data-test-icon="close-small"]');
    t = (r == null ? void 0 : r.closest("button")) || null;
  }
  if (t || (t = ((o = hs('svg[data-test-icon="close-small"]')) == null ? void 0 : o.closest("button")) || null), t) {
    const r = t.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) {
      const a = Math.round(r.left + r.width / 2), i = Math.round(r.top + r.height / 2);
      if (l("dismissMessagingOverlay: cdp-click close", { x: a, y: i }), chrome.runtime.sendMessage({ action: "cdpClick", x: a, y: i }).catch(() => {
      }), await Dt(2e3)) return;
      l("dismissMessagingOverlay: close click didn't clear composer, sending Escape");
    }
  }
  l("dismissMessagingOverlay: sending Escape"), chrome.runtime.sendMessage({ action: "cdpEscape" }).catch(() => {
  }), await Dt(1500) || l("dismissMessagingOverlay: Escape didn't clear composer either", { dom: ye(we) });
}
function bs() {
  let e = !1;
  const t = document.querySelector(
    '.msg-overlay-bubble-header__control .artdeco-button__icon[data-test-icon="close-small"]'
  );
  t != null && t.parentElement && (G(t.parentElement), e = !0);
  const o = B || vn().trim();
  if (o) {
    const a = me((i) => {
      var c;
      return ((c = i.textContent) == null ? void 0 : c.trim()) === "Add a note" && !i.disabled;
    });
    if (a) {
      G(a);
      const i = document.querySelector(
        ".send-invite textarea, [role='dialog'] textarea, .artdeco-modal textarea"
      );
      i ? (i.value = o, i.dispatchEvent(new Event("input", { bubbles: !0 })), i.dispatchEvent(new Event("change", { bubbles: !0 })), q("open", "ok", "note_written", { ai: !!B, len: o.length })) : q("open", "fail", "textarea_not_found", {}), B = "", e = !0;
    }
  }
  const r = me((a) => {
    var i;
    const c = ((i = a.textContent) == null ? void 0 : i.replace(/\s+/g, " ").trim()) || "";
    const u = (a.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
    return /^(Send|Send invitation|Send without a note|Send now)$/i.test(c || u) && !a.disabled;
  });
  return r ? (G(r), q("send", "ok", "send_clicked", {}), "sent") : e ? "acted" : "none";
}
function connectionWasSubmitted(e) {
  if (!e) return !1;
  if (!e.isConnected) {
    const t = Array.from(document.querySelectorAll(".send-invite, [role='dialog'], .artdeco-modal")).some((n) => n.getClientRects().length > 0 && /Connect|Add a note|Send/i.test(n.textContent || ""));
    return !t;
  }
  const n = (e.textContent || "").replace(/\s+/g, " ").trim();
  return /^(Pending|Message|Following|Connected|Requested|Withdraw|Sent)$/i.test(n);
}
function ys(button) {
  return new Promise((resolve) => {
    let n = 0;
    const t = setInterval(() => {
      if (bs() === "sent" || connectionWasSubmitted(button)) {
        clearInterval(t), resolve(!0);
        return;
      }
      ++n >= fe && (clearInterval(t), q("send", "fail", "send_not_confirmed", { attempts: n }), resolve(!1));
    }, 500);
  });
}
function Nt() {
  const e = me((n) => {
    var t;
    return ((t = n.textContent) == null ? void 0 : t.trim()) === "Next" && !n.disabled;
  });
  e && G(e);
}
function M() {
  chrome.runtime.sendMessage({
    action: "stateUpdated",
    isRunning: y(),
    count: je(),
    commentCount: Ue(),
    postCount: Qe(),
    messageCount: et(),
    firstMessageCount: qe(),
    replyTarget: (x == null ? void 0 : x.correspondent) || "",
    firstMessageTarget: ce || "",
    connectTarget: Ie,
    commentTarget: Ve
  }).catch(() => {
  });
}
function _() {
  y() && [F.MyNetwork, F.SearchPeople].includes(oe()) ? ds() : y() && oe() === F.PostSearch ? xs() : y() && oe() === F.PostFeed ? Es() : y() && oe() === F.Messaging ? Ys() : y() && oe() === F.Connections && ps();
}
let Y = "";
function ws(e) {
  var o, r, a;
  const n = Cs(e);
  if (n && n.author) return n;
  let t = e.parentElement;
  for (let i = 0; i < 15 && !(!t || t === document.body); i++) {
    if (t.getAttribute("data-urn") || t.classList.contains("feed-shared-update-v2") || t.querySelector('a[href*="/in/"]')) {
      let c = "";
      const u = t.querySelector('a[href*="/in/"]');
      if (u) {
        if (c = (u.getAttribute("aria-label") || "").trim(), c || (c = Array.from(u.querySelectorAll("span")).filter((h) => h.offsetParent !== null).map((h) => {
          var D;
          return (D = h.textContent) == null ? void 0 : D.trim();
        }).join(" ")), c || (c = ((o = u.textContent) == null ? void 0 : o.trim().replace(/\s+/g, " ")) || ""), !c || c.length < 2) {
          const f = u.querySelector("img");
          f && (c = (f.getAttribute("alt") || "").trim());
        }
        if (!c || c.length < 2) {
          const f = document.createTreeWalker(u, NodeFilter.SHOW_TEXT);
          for (; f.nextNode(); ) {
            const h = ((r = f.currentNode.textContent) == null ? void 0 : r.trim()) || "";
            if (h.length >= 2 && h.length <= 60) {
              c = h;
              break;
            }
          }
        }
      }
      c = gt(c).substring(0, 60);
      const g = [], s = document.createTreeWalker(t, NodeFilter.SHOW_TEXT);
      for (; s.nextNode(); ) {
        const f = s.currentNode.parentElement;
        if (!f || f.closest("button") || f.closest("a") || f.closest("h1,h2,h3,h4,h5,h6") || f.closest("[role='button']") || f.offsetParent === null) continue;
        const h = ((a = s.currentNode.textContent) == null ? void 0 : a.trim().replace(/\s+/g, " ")) || "";
        h.length < 10 || h.length > 500 || h === "Comment" || h === "Like" || h === "Share" || h === "Repost" || h === "Send" || h.includes("Comment as") || h.includes("Add a comment") || h !== c && g.push(h);
      }
      const m = g.slice(0, 5).join(" | ").substring(0, 800);
      return l("extractPostContent", { author: c || "(none)", textLen: m.length }), { author: c, text: m };
    }
    t = t.parentElement;
  }
  return { author: "", text: "" };
}
function Ms(e) {
  const n = Object.keys(e).find(
    (t) => t.startsWith("__reactFiber$") || t.startsWith("__reactInternalInstance$")
  );
  return n ? e[n] : null;
}
function Cs(e) {
  let n = Ms(e);
  if (!n) return null;
  let t = "", o = "", r = n;
  for (let a = 0; a < 30 && r; a++) {
    const i = r.memoizedProps || r.pendingProps || {};
    if (!t) {
      const c = i.actorName || i.authorName;
      if (c && typeof c == "string" && (t = c), !t && i.actor && typeof i.actor == "object" && (t = i.actor.name || i.actor.firstName || i.actorName || ""), !t) {
        const u = i.actor || i.author;
        u && typeof u == "string" && (t = u);
      }
    }
    if (!o) {
      const c = i.text || i.body || i.commentary;
      c && typeof c == "string" && c.length > 10 && (o = c), !o && i.content && typeof i.content == "string" && i.content.length > 10 && (o = i.content);
    }
    if (!t || !o) {
      let c = r.sibling;
      for (let u = 0; u < 5 && c && (!t || !o); u++) {
        const g = c.memoizedProps || c.pendingProps || {};
        if (!t) {
          const s = g.actorName || g.authorName;
          if (s && typeof s == "string" && (t = s), !t && g.actor && typeof g.actor == "object" && (t = g.actor.name || g.actor.firstName || g.actorName || ""), !t) {
            const m = g.actor || g.author;
            m && typeof m == "string" && (t = m);
          }
        }
        if (!o) {
          const s = g.text || g.body || g.commentary;
          s && typeof s == "string" && s.length > 10 && (o = s), !o && g.content && typeof g.content == "string" && g.content.length > 10 && (o = g.content);
        }
        c = c.sibling;
      }
    }
    if (t && o) break;
    r = r.return;
  }
  return t = gt(t).substring(0, 60), o = o.substring(0, 800), l("extractPostFromFiber", { author: t || "(none)", textLen: o.length }), o ? { author: t, text: o } : null;
}
async function Ps(e) {
  try {
    Y = await chrome.runtime.sendMessage({ action: "generateComment", post: e }), l("AI comment generated", { len: Y.length });
  } catch {
    Y = "";
  }
}
function Ss() {
  const e = Kt().filter((n) => n.trim());
  return e.length ? e[Math.floor(Math.random() * e.length)] : "";
}
async function xs() {
  if (J) return;
  J = !0;
  let e = 0;
  for (l("searchForNextPostToComment started"); e < fe && y(); ) {
    await Se(), await p((800 + Math.random() * 2200) * E());
    const n = me(wt);
    if (n) {
      l("comment button found"), P("discover", "ok", "comment_button_found", { method: "fiber" }), await ee(n), Mt({ btn: n, post: nt });
      return;
    }
    e++;
  }
  l("no comment buttons found, trying DOM fallback");
  for (const n of document.querySelectorAll("button"))
    if (wt(n)) {
      l("comment button found via DOM fallback"), P("discover", "ok", "comment_button_found", { method: "dom_fallback" }), await ee(n), Mt({ btn: n, post: nt });
      return;
    }
  l("no comment buttons found"), P("discover", "info", "no_comment_button", { attempts: e }), Do(), J = !1;
}
async function mn(e, n) {
  for (let t = 0; t < n.length; t++) {
    const o = n[t];
    if (o === `
`) {
      e.dispatchEvent(new KeyboardEvent("keydown", {
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        bubbles: !0,
        cancelable: !0,
        composed: !0
      })), document.execCommand("insertParagraph", !1), e.dispatchEvent(new InputEvent("input", {
        bubbles: !0,
        cancelable: !0,
        inputType: "insertParagraph"
      })), e.dispatchEvent(new KeyboardEvent("keyup", {
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        bubbles: !0,
        cancelable: !0,
        composed: !0
      })), await new Promise((i) => setTimeout(i, 60 + Math.random() * 80));
      continue;
    }
    const r = {
      key: o,
      bubbles: !0,
      cancelable: !0,
      composed: !0
    };
    e.dispatchEvent(new KeyboardEvent("keydown", r)), e.dispatchEvent(new InputEvent("beforeinput", {
      bubbles: !0,
      cancelable: !0,
      inputType: "insertText",
      data: o
    })), document.execCommand("insertText", !1, o), e.dispatchEvent(new InputEvent("input", {
      bubbles: !0,
      cancelable: !0,
      inputType: "insertText",
      data: o
    })), e.dispatchEvent(new KeyboardEvent("keyup", r));
    const a = 30 + Math.random() * 200 + (Math.random() < 0.05 ? 400 : 0);
    await new Promise((i) => setTimeout(i, a));
  }
}
function vs(e) {
  const n = document.querySelectorAll(
    ".tiptap.ProseMirror, [role='textbox'][contenteditable='true'], [contenteditable='true']"
  );
  for (const t of n)
    if (t.isContentEditable && !e.has(t)) return t;
  return null;
}
function Ft() {
  const e = document.querySelectorAll(
    ".tiptap.ProseMirror, [role='textbox'][contenteditable='true'], [contenteditable='true']"
  );
  for (const n of e) {
    if (!n.isContentEditable) continue;
    const t = n.getBoundingClientRect();
    if (t.width > 0 && t.height > 0)
      return l("dismissCommentComposer: sending Escape for open composer"), chrome.runtime.sendMessage({ action: "cdpEscape" }).catch(() => {
      }), !0;
  }
  return !1;
}
async function ks(e, n) {
  const t = n;
  if (!t)
    return l("fillCommentTextarea: no comment editor"), !1;
  t.dispatchEvent(new MouseEvent("mousedown", { bubbles: !0, cancelable: !0 })), t.focus(), t.dispatchEvent(new MouseEvent("mouseup", { bubbles: !0, cancelable: !0 }));
  const o = window.getSelection();
  o && (o.selectAllChildren(t), o.collapseToEnd()), await mn(t, e);
  const r = (t.textContent || "").replace(/\s+/g, " ").trim();
  return r.length < 3 ? (l("fillCommentTextarea: verification failed — editor empty", { len: r.length }), !1) : (l("fillCommentTextarea: typed", { len: e.length }), !0);
}
function Bt(e) {
  var t;
  if (e.disabled) return !1;
  const n = (t = e.textContent) == null ? void 0 : t.trim();
  return n === "Post" || n === "Comment";
}
async function Rt(e) {
  e.scrollIntoView({ block: "center", behavior: "instant" }), await p(200);
  const n = e.getBoundingClientRect(), t = Math.round(n.left + n.width / 2), o = Math.round(n.top + n.height / 2);
  l("cdpClick request", { x: t, y: o, elementText: (e.textContent || "").trim().substring(0, 40) }), chrome.runtime.sendMessage({ action: "cdpClick", x: t, y: o }).catch(() => {
  });
}
async function _s(e) {
  if (!e) return !1;
  let n = e;
  for (let t = 0; t < 12 && n !== document.body; t++) {
    const o = n.parentElement;
    if (!o) break;
    for (const r of Array.from(o.children)) {
      if (r === n) continue;
      if (r instanceof HTMLButtonElement && Bt(r))
        return await Rt(r), !0;
      const a = r.querySelectorAll("button");
      for (const i of a)
        if (Bt(i))
          return await Rt(i), !0;
    }
    n = o;
  }
  return !1;
}
async function Ts(e) {
  const n = Y || Ss();
  if (Y = "", !n)
    return l("submitComment: no text"), P("fill", "fail", "no_comment_text", {}), !1;
  const t = vs(e);
  if (!t)
    return l("submitComment: no editor after open"), P("fill", "fail", "no_editor", {}), !1;
  if (!await ks(n, t))
    return l("submitComment: fill failed"), P("fill", "fail", "fill_failed", {}), !1;
  P("fill", "ok", "editor_typed", { len: n.length });
  for (let o = 0; o < 20; o++) {
    if (!y())
      return l("submitComment: stopped"), P("send", "info", "stopped", {}), !1;
    if (await _s(t)) {
      l("submitComment: submit clicked"), P("send", "ok", "submit_clicked", { attempts: o });
      let r = !1;
      for (let a = 0; a < 8; a++)
        if (await p(500), !t.isConnected || (t.textContent || "").replace(/\s+/g, " ").trim().length < 3) {
          r = !0;
          break;
        }
      return r ? (l("submitComment: posted verified"), P("send", "ok", "submit_verified", { attempts: o }), !0) : (l("submitComment: click did not post"), P("send", "fail", "submit_unverified", { attempts: o }), !1);
    }
    await p(500);
  }
  return l("submitComment: submit button never appeared"), P("send", "fail", "submit_button_not_found", { attempts: 20 }), !1;
}
function As(e) {
  const n = ln();
  if (n) {
    let t = function(a) {
      return !a || o.has(a) ? null : (o.add(a), a.stateNode instanceof HTMLElement && e(a.stateNode) ? a.stateNode : t(a.child) || t(a.sibling));
    };
    const o = /* @__PURE__ */ new Set(), r = t(n);
    if (r) return r;
  }
  for (const t of document.querySelectorAll("button, [role='button']"))
    if (e(t)) return t;
  return null;
}
async function Es() {
  if (L) return;
  L = !0;
  let e = 0;
  for (l("searchForStartPostButton started"); e < fe && y(); ) {
    await Se(), await p((800 + Math.random() * 2200) * E());
    const n = As(
      (t) => {
        var o;
        return (t instanceof HTMLButtonElement || t.getAttribute("role") === "button") && !(t instanceof HTMLButtonElement && t.disabled) && !t.hasAttribute("aria-disabled") && (((o = t.textContent) == null ? void 0 : o.trim()) ?? "").includes("Start a post");
      }
    );
    if (n) {
      l("start post button found", { tag: n.tagName }), await ee(n), Ho(n);
      return;
    }
    e++;
  }
  l("no start post button found"), Vo(), L = !1;
}
function Ds(e, n) {
  return new Promise((t, o) => {
    const r = new Image();
    r.onload = () => {
      const a = document.createElement("canvas");
      a.width = r.naturalWidth, a.height = r.naturalHeight, a.getContext("2d").drawImage(r, 0, 0), t(a.toDataURL("image/png").split(",")[1]);
    }, r.onerror = () => o(new Error("Image decode failed")), r.src = `data:${n};base64,${e}`;
  });
}
async function Ns(e, n) {
  try {
    const t = n === "image/png" ? e : await Ds(e, n), o = atob(t), r = new Uint8Array(o.length);
    for (let i = 0; i < o.length; i++) r[i] = o.charCodeAt(i);
    const a = new Blob([r], { type: "image/png" });
    return await navigator.clipboard.write([
      new ClipboardItem({ "image/png": a })
    ]), l("writeImageToClipboard: success", { size: o.length }), !0;
  } catch (t) {
    return l("writeImageToClipboard: failed", t), !1;
  }
}
function Fs(e) {
  function n(t) {
    var o, r;
    try {
      const a = (o = t.querySelector) == null ? void 0 : o.call(t, e);
      if (a) return a;
      const i = ((r = t.querySelectorAll) == null ? void 0 : r.call(t, "*")) || [];
      for (const c of i)
        if (c.shadowRoot) {
          const u = n(c.shadowRoot);
          if (u) return u;
        }
    } catch {
    }
    return null;
  }
  return n(document);
}
function Bs(e) {
  var n, t;
  for (let o = 0; o < 30; o++) {
    const r = Fs('.ql-editor[contenteditable="true"][role="textbox"]');
    if (r) {
      let i = r;
      for (let c = 0; c < 10 && i; c++) {
        const u = i.__quill;
        if (u && typeof u.setContents == "function")
          return u.setContents([{ insert: e + `
` }], "api"), l("fillPostEditor: Quill.setContents via shadow walk"), !0;
        i.getRootNode() instanceof ShadowRoot ? i = i.getRootNode().host : i = i.parentElement;
      }
      return r.focus(), r.innerHTML = "<p>" + e + "</p>", r.dispatchEvent(new InputEvent("input", { bubbles: !0 })), l("fillPostEditor: innerHTML fallback via shadow DOM"), !0;
    }
    const a = document.querySelector('.ql-editor[contenteditable="true"][role="textbox"]');
    if (a) {
      const i = (t = (n = a.parentElement) == null ? void 0 : n.parentElement) == null ? void 0 : t.__quill;
      return i != null && i.setContents ? (i.setContents([{ insert: e + `
` }], "api"), !0) : (a.focus(), a.innerHTML = "<p>" + e + "</p>", a.dispatchEvent(new InputEvent("input", { bubbles: !0 })), !0);
    }
  }
  return l("fillPostEditor: polled 30 times, no editor found"), !1;
}
function Rs(e) {
  const n = [];
  function t(o) {
    var r, a;
    try {
      const i = (r = o.querySelectorAll) == null ? void 0 : r.call(o, e);
      if (i) for (const u of i) n.push(u);
      const c = ((a = o.querySelectorAll) == null ? void 0 : a.call(o, "*")) || [];
      for (const u of c)
        u.shadowRoot && t(u.shadowRoot);
    } catch {
    }
  }
  return t(document), n;
}
function qs() {
  var e, n;
  for (const t of Rs("button, [role='button']"))
    if (((e = t.textContent) == null ? void 0 : e.trim()) === "Post" && !(t instanceof HTMLButtonElement && t.disabled))
      return t.click(), l("clickPostSubmit: clicked Post button"), !0;
  for (const t of document.querySelectorAll("button, [role='button']"))
    if (((n = t.textContent) == null ? void 0 : n.trim()) === "Post" && !(t instanceof HTMLButtonElement && t.disabled))
      return t.click(), l("clickPostSubmit: clicked Post button (light DOM)"), !0;
  return l("clickPostSubmit: no Post button found"), !1;
}
let b = null;
function dn() {
  const e = Gn().filter((n) => n.trim());
  return e.length ? e[Math.floor(Math.random() * e.length)] : "";
}
function Os() {
  const e = Number(mt()) || 30, n = Number(dt()) || 120, t = Math.max(0, n - e);
  return (e + Math.random() * t) * 6e4 * (0.85 + Math.random() * 0.3) * E();
}
async function qt() {
  const e = Wn(), n = Un() || void 0;
  try {
    const o = await chrome.runtime.sendMessage({
      action: "generatePostContent",
      topic: e || "",
      imagePrompt: n
    });
    if (o && (o.text || o.imageBase64))
      return l("generatePostContent: AI returned", { hasText: !!o.text, hasImage: !!o.imageBase64 }), o;
  } catch (o) {
    l("generatePostContent: error", o);
  }
  const t = dn();
  return t ? (l("generatePostContent: using pool text"), { text: t }) : null;
}
let x = null, ce = "", Ie = "", Ve = "", j = !1, Me = /* @__PURE__ */ new Set();
const ut = /* @__PURE__ */ new Set(), fn = /* @__PURE__ */ new Set();
function Hs() {
  const e = eo().filter((n) => n.trim());
  return e.length ? e[Math.floor(Math.random() * e.length)] : "";
}
async function Is(e, n) {
  try {
    const t = await chrome.runtime.sendMessage({
      action: "generateReply",
      conversation: {
        correspondent: e.correspondent,
        headline: e.headline,
        lastMessages: n
      }
    });
    return l("AI reply generated", { len: (t == null ? void 0 : t.length) || 0 }), t || "";
  } catch {
    return "";
  }
}
function X(e) {
  if (!e) return !1;
  const n = e.getBoundingClientRect();
  if (n.width <= 0 || n.height <= 0) return !1;
  const t = getComputedStyle(e);
  return !(t.display === "none" || t.visibility === "hidden");
}
function Ce(e) {
  const n = e.getBoundingClientRect();
  return {
    tag: e.tagName,
    role: e.getAttribute("role"),
    ariaLabel: e.getAttribute("aria-label"),
    className: e.className.substring(0, 60),
    rect: { w: Math.round(n.width), h: Math.round(n.height) },
    visible: X(e)
  };
}
function Vs(e) {
  const n = e.querySelector("button.msg-form__send-button");
  if (n && X(n)) return n;
  for (const t of e.querySelectorAll("button"))
    if ((t.textContent || "").trim() === "Send" && X(t)) return t;
  return null;
}
function O(e = document) {
  const n = [];
  function t(r) {
    const a = r.querySelectorAll(
      'div.msg-form__contenteditable[contenteditable="true"][role="textbox"]'
    );
    for (const c of a) n.push(c);
    const i = r.querySelectorAll(
      '[contenteditable="true"][role="textbox"][aria-label^="Write a message"]'
    );
    for (const c of i) n.includes(c) || n.push(c);
    for (const c of r.querySelectorAll("*"))
      c.shadowRoot && t(c.shadowRoot);
  }
  t(e);
  const o = n.filter(X);
  l("findActiveMessageComposer", {
    totalEditors: n.length,
    visibleEditors: o.length
  });
  for (const r of o) {
    const a = r.closest("form.msg-form");
    if (!a || !X(a)) {
      l("findActiveMessageComposer: composer missing/hidden", Ce(r));
      continue;
    }
    const i = Vs(a);
    if (!i) {
      l("findActiveMessageComposer: no visible Send button in composer", {
        ...Ce(r),
        composerClass: a.className.substring(0, 60)
      });
      continue;
    }
    return l("findActiveMessageComposer: resolved", {
      ...Ce(r),
      composerTag: a.tagName,
      composerClass: a.className.substring(0, 60),
      sendBtnDisabled: i.disabled,
      sendBtnVisible: X(i)
    }), { editor: r, composer: a, sendButton: i };
  }
  return l("findActiveMessageComposer: no match", { editorsChecked: o.length }), null;
}
async function $s(e = 9e3) {
  const n = O();
  return n || new Promise((t) => {
    let o = !1;
    const r = (u) => {
      o || (o = !0, clearTimeout(a), clearInterval(i), c.disconnect(), t(u));
    }, a = setTimeout(() => {
      l("waitForMessageComposer: timeout, final poll"), r(O());
    }, e), i = setInterval(() => {
      const u = O();
      u && r(u);
    }, 400), c = new MutationObserver(() => {
      const u = O();
      u && r(u);
    });
    c.observe(document.body, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["class", "style"]
    });
  });
}
function Le() {
  const e = O();
  return e ? e.editor : null;
}
function gn() {
  var t;
  let n = Pe(".msg-s-event-listitem")[0] || null;
  for (; n && n !== document.body; ) {
    if (n.scrollHeight > n.clientHeight + 20) {
      n.scrollTop = n.scrollHeight;
      return;
    }
    n = n.parentElement || ((t = n.getRootNode()) == null ? void 0 : t.host) || null;
  }
}
function Ls(e = 9e3) {
  return new Promise((n) => {
    let t = !1;
    const o = (i) => {
      t || (t = !0, clearTimeout(r), a.disconnect(), n(i));
    }, r = setTimeout(() => o($e().length > 0), e), a = new MutationObserver(() => {
      $e().length > 0 && o(!0);
    });
    a.observe(document.body, { childList: !0, subtree: !0 });
  });
}
async function pn(e, n) {
  const t = n && X(n) ? n : Le();
  if (!t)
    return l("fillMessageTextarea: no visible editor", { editorProvided: !!n }), !1;
  if (l("fillMessageTextarea: editor resolved", Ce(t)), t.dispatchEvent(new MouseEvent("mousedown", { bubbles: !0, cancelable: !0 })), t.focus(), t.dispatchEvent(new MouseEvent("mouseup", { bubbles: !0, cancelable: !0 })), !t.isContentEditable)
    return l("fillMessageTextarea: element is not contentEditable"), !1;
  const o = window.getSelection();
  o && (o.selectAllChildren(t), o.collapseToEnd()), await mn(t, e);
  const r = Le();
  if (!r)
    return l("fillMessageTextarea: editor disappeared after typing"), !1;
  const a = (r.textContent || "").replace(/\s+/g, " ").trim();
  if (a.length < 3)
    return l("fillMessageTextarea: verification failed — editor empty", { editorLen: a.length }), !1;
  const i = O();
  if (!i || !i.sendButton)
    return l("fillMessageTextarea: post-type composer/send-btn not found"), !0;
  if (i.sendButton.disabled) {
    l("fillMessageTextarea: Send button still disabled after typing"), i.editor.dispatchEvent(new InputEvent("input", { bubbles: !0, inputType: "insertText" }));
    const c = O();
    if (c != null && c.sendButton && c.sendButton.disabled)
      return l("fillMessageTextarea: Send button remained disabled — text not registered"), !1;
  }
  return l("fillMessageTextarea: typed", { len: e.length, hasBreaks: e.includes(`
`) }), !0;
}
function hn(e) {
  var t;
  const n = e && X(e) ? e : (t = O()) == null ? void 0 : t.sendButton;
  return n ? n.disabled ? (l("clickMessageSend: Send button is disabled"), !1) : (l("clickMessageSend: resolved", {
    disabled: n.disabled,
    visible: X(n),
    className: n.className.substring(0, 60)
  }), n.dispatchEvent(new MouseEvent("mouseenter", { bubbles: !0 })), n.dispatchEvent(new MouseEvent("mouseover", { bubbles: !0 })), n.dispatchEvent(new PointerEvent("pointerdown", { bubbles: !0, pointerId: 1 })), n.dispatchEvent(new MouseEvent("mousedown", { bubbles: !0, cancelable: !0 })), n.dispatchEvent(new MouseEvent("mouseup", { bubbles: !0, cancelable: !0 })), n.dispatchEvent(new PointerEvent("pointerup", { bubbles: !0, pointerId: 1 })), n.click(), l("clickMessageSend: clicked Send"), !0) : (l("clickMessageSend: no Send button resolved"), !1);
}
function bn() {
  const e = Le();
  return e ? (e.textContent || "").replace(/\s+/g, " ").trim().length === 0 : !0;
}
function yn(e) {
  const n = e.replace(/\s+/g, " ").trim().substring(0, 20);
  if (!n) return !1;
  for (const t of Pe(".msg-s-event-listitem__body"))
    if ((t.textContent || "").replace(/\s+/g, " ").trim().includes(n)) return !0;
  return !1;
}
function Ks() {
  const e = document.querySelectorAll(".msg-s-event-listitem");
  return e.length === 0 ? !1 : !e[e.length - 1].classList.contains("msg-s-event-listitem--other");
}
function Ws() {
  const e = Pe(".msg-s-event-listitem"), n = e.length > 0, t = n && !e[e.length - 1].classList.contains("msg-s-event-listitem--other"), o = n && !!Pe(".msg-s-event-listitem--other").length;
  return { hasThread: n, latestOurs: t, hasInbound: o };
}
function js(e) {
  const n = pt(e);
  if (n && fn.has(n)) return !0;
  const t = e.querySelectorAll("span");
  for (const o of t) {
    const r = (o.textContent || "").replace(/\s+/g, " ").trim();
    if (r) {
      if (/^1st\b/.test(r)) return !0;
      if (/^(?:2nd|3rd|3rd\+)\b/.test(r)) return !1;
    }
  }
  return !1;
}
async function Ys() {
  var n, t, o;
  if (T) return;
  T = !0;
  let e = 0;
  for (l("searchForNextConversation started"); e < fe && y(); ) {
    await Se(), await p((800 + Math.random() * 2200) * E());
    const r = document.querySelectorAll("li.msg-conversation-listitem");
    for (const a of r) {
      const i = pt(a);
      if (i && Ee.has(i)) continue;
      const c = ((n = a.textContent) == null ? void 0 : n.trim()) || "";
      if (c.includes("Sponsored") || c.length < 15) {
        i && Ee.add(i);
        continue;
      }
      if (so() && !js(a)) {
        S("discover", "skip", "non_connection", { participant: i }), i && Ee.add(i);
        continue;
      }
      const u = ((o = (t = a.querySelector(".msg-conversation-card__message-snippet")) == null ? void 0 : t.textContent) == null ? void 0 : o.replace(/\s+/g, " ").trim()) || "", g = a.querySelector(".msg-conversation-listitem__link") || a;
      i && Ee.add(i), st = u, rt = i, S("discover", "ok", "conversation_found", { participant: i, snippet: u }), await ee(g), Uo(g);
      return;
    }
    e++;
  }
  S("discover", "info", "no_eligible", { attempts: e }), Go(), T = !1;
}
(async () => {
  await lo(), await ss(), await rs(), await is(), await as();
  const { commentedAuthors: e, commentedPosts: n, postFingerprints: t, conversations: o, messagedConns: r } = await chrome.storage.local.get(["commentedAuthors", "commentedPosts", "postFingerprints", "conversations", "messagedConns"]);
  for (const s of e || []) le.add(s);
  for (const s of n || []) ue.add(s);
  for (const s of t || []) pe.add(s);
  for (const s of (o == null ? void 0 : o.replied) || []) Oe.add(s);
  for (const s of (o == null ? void 0 : o.skipped) || []) ot.add(s);
  for (const s of r || []) Me.add(s);
  const { "db:leads": a } = await chrome.storage.local.get("db:leads");
  for (const s of a || [])
    ["connected", "messaged", "replied"].includes(s.status) && fn.add(s.name);
  setInterval(() => {
    const s = window.location.href;
    s.includes(Z.PatternOfPostSearchPage) ? Ro() : s.includes(Z.PatternOfFeedPage) ? Wo() : s.includes(Z.PatternOfMessagingPage) ? es() : s.includes(Z.PatternOfConnectionsPage) ? ns() : s.includes(Z.PatternOfSearchPage) ? xo() : s.includes(Z.PatternOfMyNetworkPage) && ko();
  }, 1e3), vo(() => {
    ne(F.SearchPeople), _();
  }), _o(() => {
    ne(F.MyNetwork), _();
  }), qo(() => {
    ne(F.PostSearch), _();
  }), jo(() => {
    ne(F.PostFeed), _();
  }), ts(() => {
    ne(F.Messaging), _();
  }), os(() => {
    ne(F.Connections), _();
  }), chrome.storage.onChanged.addListener((s) => {
    s.speedPreset && Ht(s.speedPreset.newValue), s.maximumAutoConnectionsPerDay && Ot(s.maximumAutoConnectionsPerDay.newValue || Ke()), s.connectionNote && It(s.connectionNote.newValue || ""), s.sessionDurationMinutes && Vt(s.sessionDurationMinutes.newValue || "0"), s.maximumAutoCommentsPerDay && $t(s.maximumAutoCommentsPerDay.newValue || Ye()), s.commentPool && Lt(s.commentPool.newValue || [""]), s.commentSearchKeyword && Wt(s.commentSearchKeyword.newValue || ""), s.autoCommentDaily && jt(s.autoCommentDaily.newValue ?? !1), s.commentScheduleHour && Yt(s.commentScheduleHour.newValue || "9"), s.maximumAutoPostsPerDay && Xt(s.maximumAutoPostsPerDay.newValue || ze()), s.postTopic && Gt(s.postTopic.newValue || ""), s.postIntervalMinutesMin && Qt(s.postIntervalMinutesMin.newValue || mt()), s.postIntervalMinutesMax && Zt(s.postIntervalMinutesMax.newValue || dt()), s.postImagePrompt && Jt(s.postImagePrompt.newValue || ""), s.postTextPool && en(s.postTextPool.newValue || [""]), s.autoPostDaily && Ut(s.autoPostDaily.newValue ?? !1), s.postScheduleHour && zt(s.postScheduleHour.newValue || "10"), s.maximumAutoMessagesPerDay && tn(s.maximumAutoMessagesPerDay.newValue || Ze()), s.messageReplyPool && nn(s.messageReplyPool.newValue || [""]), s.autoMessageDaily && on(s.autoMessageDaily.newValue ?? !1), s.messageScheduleHour && sn(s.messageScheduleHour.newValue || "9"), s.replyToConnectionsOnly && rn(s.replyToConnectionsOnly.newValue ?? !1), s.messageFirstPool && an(s.messageFirstPool.newValue || [""]), s.maximumAutoFirstMessagesPerDay && cn(s.maximumAutoFirstMessagesPerDay.newValue || ft());
  }), chrome.runtime.onMessage.addListener((s, m, f) => {
    if (s.action === "start" && Co(), s.action === "stop" && $(), s.action === "auditDom") {
      const h = cs();
      return l("auditDom", h), chrome.storage.local.set({ "dom:audit": { ts: Date.now(), ...h } }).catch(() => {
      }), f && f(h), !0;
    }
  });
  let i = 0;
  Po(() => {
    i = Date.now(), ut.clear(), bt(!0), M();
  }), So(() => {
    be = !1, J = !1, L = !1, T = !1, j = !1, Ie = "", Ve = "", bt(!1), M(), Ft();
  });
  function c() {
    const s = Number(Nn());
    return s <= 0 ? !1 : Date.now() - i >= s * 6e4;
  }
  let u = { name: "", headline: "" };
  const g = (s) => {
    const m = je(), f = m + 1;
    We(f), uo(f), Ie = "", M(), q("record", "ok", "connection_recorded", {
      name: u.name,
      headline: u.headline,
      hadAiNote: s,
      countBefore: m,
      countAfter: f
    }), chrome.runtime.sendMessage({
      action: "reportConnected",
      data: { name: u.name, headline: u.headline }
    }).catch(() => {
    }), s && chrome.runtime.sendMessage({
      action: "reportActivity",
      data: { connections: 0, comments: 0, posts: 0, messagesSent: 1, messagesReceived: 0 }
    }).catch(() => {
    });
  };
  Mo(async () => {
    const s = !!B;
    const m = connectionButton;
    const f = await ys(m);
    connectionButton = null;
    f && g(s), await p(He()), be = !1, y() && (c() ? (l("session duration cap reached, stopping"), $()) : je() >= Number(Ke()) ? $() : _());
  }), Cn(() => M()), To(() => {
    M(), _();
  }), ho(async (s) => {
    s.dataset.autoconnected = "true", u = us(s), Ie = u.name, M(), u.name ? q("extract", "ok", "profile_extracted", { name: u.name, headline: u.headline }) : q("extract", "fail", "no_name", { headline: u.headline });
    const m = ms(u);
    await Promise.race([m, p(4e3 * E())]), q("generate", B ? "ok" : "info", B ? "ai_note" : "no_ai_note", { len: B.length }), B && ls(B, u.name), connectionButton = s, G(s), wo();
  }), yo(() => Nt()), Eo(async ({ btn: s, post: m }) => {
    if (!y()) return;
    P("extract", "ok", "author_extracted", {
      author: z(m.author),
      textLen: m.text.length
    });
    const f = he(m.text);
    if (f && ue.has(f) || le.has(z(m.author))) {
      l("skipping already-commented post, searching next"), P("extract", "skip", "already_commented_post", { author: z(m.author) }), J = !1, await p(500), _();
      return;
    }
    Ve = m.author, M();
    const h = Ps(m);
    Ft() && await p(500);
    const D = new Set(
      Array.from(document.querySelectorAll(".tiptap.ProseMirror, [role='textbox'][contenteditable='true'], [contenteditable='true']")).filter((w) => w.isContentEditable)
    );
    if (G(s), await p((500 + Math.random() * 1e3) * E()), await Promise.race([h, p(4e3 * E())]), P("generate", Y ? "ok" : "info", Y ? "ai_comment" : "pool_fallback", {
      len: Y.length
    }), l("postComment pre-submit", {
      running: y(),
      aiLen: Y.length,
      poolLen: Kt().filter((w) => w.trim()).length
    }), !y()) {
      P("send", "info", "stopped_before_submit", {});
      return;
    }
    await Ts(D) ? (le.add(z(m.author)), f && ue.add(f), yt(), P("record", "ok", "post_deduped", {
      author: z(m.author),
      fingerprint: f.substring(0, 40)
    }), Fo()) : (m.author && le.add(z(m.author)), f && ue.add(f), yt(), P("record", "skip", "post_skipped", {
      author: z(m.author),
      fingerprint: f.substring(0, 40)
    }), J = !1, await p(500), _());
  }), Bo(async () => {
    const s = Ue(), m = s + 1;
    P("record", "ok", "count_incremented", { countBefore: s, countAfter: m }), Xe(m), mo(m), Ve = "", M(), chrome.runtime.sendMessage({
      action: "reportActivity",
      data: { connections: 0, comments: 1, posts: 0, messagesSent: 0, messagesReceived: 0 }
    }).catch(() => {
    }), await p(He()), J = !1, y() && (c() ? (l("session duration cap reached, stopping"), $()) : Ue() >= Number(Ye()) ? $() : _());
  }), No(() => Nt()), Io(async (s) => {
    var v, N;
    if (!y()) return;
    if ((!b || !b.text && !b.imageBase64) && (b = await qt()), !(b != null && b.text) && !(b != null && b.imageBase64)) {
      l("no post content generated"), L = !1;
      return;
    }
    chrome.runtime.sendMessage({
      action: "postPreview",
      text: b.text || "",
      imageBase64: b.imageBase64,
      imageMimeType: b.imageMimeType
    }).catch(() => {
    });
    const m = he(b.text || "");
    if (m && pe.has(m)) {
      l("post text already posted this session, regenerating"), b = await qt(), (b != null && b.text || b != null && b.imageBase64) && chrome.runtime.sendMessage({
        action: "postPreview",
        text: b.text || "",
        imageBase64: b.imageBase64,
        imageMimeType: b.imageMimeType
      }).catch(() => {
      });
      const C = he((b == null ? void 0 : b.text) || "");
      if (C && pe.has(C)) {
        l("regenerated text also a duplicate, stopping"), L = !1;
        return;
      }
    }
    s.scrollIntoView({ block: "center", behavior: "instant" }), await p(500);
    const f = s.getBoundingClientRect(), h = Math.round(f.left + f.width / 2), D = Math.round(f.top + f.height / 2);
    if (l("cdpClick request", { x: h, y: D, elementTag: s.tagName, elementText: (s.textContent || "").trim().substring(0, 40) }), chrome.runtime.sendMessage({
      action: "cdpClick",
      x: h,
      y: D
    }), await p((3e3 + Math.random() * 2e3) * E()), !y()) return;
    let A = !1;
    const w = (b == null ? void 0 : b.text) || dn();
    if (!w) {
      l("no post text available"), L = !1;
      return;
    }
    for (let C = 0; C < 15 && y(); C++) {
      if (Bs(w)) {
        if (l("post editor filled"), b != null && b.imageBase64 && !b.imageUploaded && await Ns(
          b.imageBase64,
          b.imageMimeType || "image/jpeg"
        )) {
          chrome.runtime.sendMessage({ action: "cdpPaste" }), b.imageUploaded = !0, l("image written to clipboard, paste requested");
          let te = !0;
          for (let K = 0; K < 15; K++) {
            await p(600);
            const R = document.querySelector(
              ".share-box__image-preview, .image-preview__container, [data-testid='image-container'], .share-creation-share-box__image, img.feed-shared-image__image"
            );
            if (R && R instanceof HTMLElement && R.offsetParent !== null) {
              l("attachment preview detected", { selector: ((N = (v = R.className) == null ? void 0 : v.substring) == null ? void 0 : N.call(v, 0, 40)) || R.tagName });
              break;
            }
            K === 14 && (te = !1);
          }
          te ? await p(1500) : l("no attachment preview after paste — submitting anyway");
        }
        if (await p(500), qs()) {
          l("post submit clicked"), A = !0;
          const V = he(w);
          V && pe.add(V), Oo(), b = null, chrome.runtime.sendMessage({ action: "postPreviewCleared" }).catch(() => {
          }), await p(2e3);
          break;
        }
      }
      await p(1e3);
    }
    A ? Lo() : L = !1;
  }), Ko(async () => {
    const s = Qe() + 1;
    Ge(s), fo(s), M(), chrome.runtime.sendMessage({
      action: "reportActivity",
      data: { connections: 0, comments: 0, posts: 1, messagesSent: 0, messagesReceived: 0 }
    }).catch(() => {
    });
    const m = Os();
    l("post cooldown", { intervalMs: m }), await p(m), L = !1, y() && (c() ? (l("session duration cap reached, stopping"), $()) : Qe() >= Number(ze()) ? $() : _());
  }), $o(() => {
    L = !1;
  }), zo(async (s) => {
    var ke;
    if (!y()) return;
    const m = st, f = rt;
    st = "", rt = "", G(s);
    const h = await Ls(), D = $e().length;
    h && (gn(), await p(500));
    const A = $e();
    if (S("open", h ? "ok" : "fail", "thread_opened", {
      threadReady: h,
      countBefore: D,
      countAfter: A.length,
      activeParticipant: Yo(),
      expected: f
    }), A.length === 0) {
      S("extract", "skip", "no_inbound", {}), x = null, T = !1;
      return;
    }
    if (Ks()) {
      S("dedup", "skip", "latest_message_ours", {}), x = null, M(), T = !1;
      return;
    }
    const w = A[A.length - 1], v = !w.sender && !!f;
    if (!w.sender && f && (w.sender = f), !w.sender) {
      S("extract", "skip", "no_sender", {}), x = null, T = !1;
      return;
    }
    const N = { correspondent: w.sender, headline: "", threadUrl: "" };
    if (x = N, S("extract", "ok", "inbound_read", {
      count: A.length,
      hasUrn: !!w.urn,
      senderSource: v ? "row_participant" : "message_group_name",
      correspondent: w.sender
    }), /^You[:\s]/i.test(m)) {
      S("dedup", "skip", "latest_is_ours", { snippet: m }), x = null, M(), T = !1;
      return;
    }
    const C = w.urn || Xo(w.sender, w.text), V = w.urn ? "urn" : "fingerprint";
    if (C && Oe.has(C)) {
      S("dedup", "skip", "already_replied", { keySource: V, key: C }), x = null, M(), T = !1;
      return;
    }
    chrome.runtime.sendMessage({
      action: "reportMessaged",
      data: { name: N.correspondent, headline: N.headline, profileUrl: N.threadUrl }
    }).catch(() => {
    });
    const te = Is(N, A), K = await Promise.race([te, p(12e3 * E())]);
    if (!y()) {
      x = null, M(), T = !1;
      return;
    }
    const R = K || Hs();
    if (!R) {
      S("generate", "skip", "no_reply_text", { aiReturned: !!K }), x = null, M(), T = !1;
      return;
    }
    S("generate", "ok", K ? "ai_reply" : "pool_reply", { len: R.length });
    let xe = !1;
    for (let Q = 0; Q < 5; Q++) {
      if (!y()) {
        x = null, M(), T = !1;
        return;
      }
      if (Le()) break;
      await p(800);
    }
    M();
    const ve = await pn(R);
    if (S("fill", ve ? "ok" : "fail", "composer_filled", {}), ve) {
      await p(300);
      for (let Q = 0; Q < 5; Q++) {
        if (hn((ke = O()) == null ? void 0 : ke.sendButton)) {
          await p(1500);
          const W = bn(), U = yn(R);
          W || U ? (S("send", "ok", "send_verified", { editorEmpty: W, textInThread: U }), xe = !0) : S("send", "fail", "send_unverified", { editorEmpty: W, textInThread: U });
          break;
        }
        await p(500);
      }
    }
    xe ? (C && (Oe.add(C), Ct()), S("record", "ok", "recorded_replied", { keySource: V, key: C }), x != null && x.correspondent && chrome.runtime.sendMessage({
      action: "reportReplied",
      data: { name: x.correspondent, replyText: R }
    }).catch(() => {
    }), Zo()) : (C && (ot.add(C), Ct()), S("record", "skip", "recorded_skipped", { keySource: V, key: C }), T = !1), x = null, M();
  }), Jo(async () => {
    const s = et() + 1;
    Je(s), go(s), M(), chrome.runtime.sendMessage({
      action: "reportActivity",
      data: { connections: 0, comments: 0, posts: 0, messagesSent: 1, messagesReceived: 0 }
    }).catch(() => {
    }), await p(He()), T = !1, y() && (c() ? (l("session duration cap reached, stopping"), $()) : et() >= Number(Ze()) ? $() : _());
  }), Qo(() => {
    T = !1;
  }), M();
})();
